/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.app.ActionBar;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.*;

import co.acoustic.mobile.push.sdk.util.Logger;

/**
 * This class is the inbox fragment
 */
public class RichInboxFragment extends Fragment {
   private static final String TAG = "RichInboxFragment";
    private int currentIndex = 0;

    int getCurrentIndex()
    {
        return currentIndex;
    }

    /**
     * Sets the fragment's view group
     * @param viewGroup The view group
     */
    public void setViewGroup(ViewGroup viewGroup) {
        viewGroup = viewGroup;
    }

    /**
     * Sets the inbox current index
     * @param currentIndex The current index
     */
    public void setCurrentIndex(int currentIndex) {
        this.currentIndex = currentIndex;

    }

    /**
     * Called when the fragment is created.
     * @param savedInstanceState The saved fragment state
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        newMessageReceiver  = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                try {
                    RichInboxListFragment richInboxListFragment = (RichInboxListFragment) getFragmentManager().findFragmentById(getResources().getIdentifier("rich_inbox_list", "id", getView().getContext().getPackageName()));
                    if (richInboxListFragment == null) {
                        int count = intent.getIntExtra("count", 0);
                        if (count < 5) {
                            Intent retryIntent = new Intent("MPNewMessage");
                            retryIntent.putExtra("count", count + 1);
                            context.sendBroadcast(retryIntent);
                            return;
                        }
                    }
                    richInboxListFragment.restartLoader();
                    getActivity().invalidateOptionsMenu();
                } catch (Throwable t) {
                    Logger.e(TAG, "Message receiver failed", t);
                }
            }
        };
        getActivity().registerReceiver(newMessageReceiver,
                new IntentFilter("MPNewMessage"));
    }



    @Override
    public void onDestroy() {
        try {
            if(newMessageReceiver != null) {
                getActivity().unregisterReceiver(newMessageReceiver);
            }
        } catch (Throwable t) {
            Logger.e(TAG,"Failed to unregister receiver", t);
        } finally {
            newMessageReceiver = null;
        }
        super.onDestroy();
    }

    private BroadcastReceiver newMessageReceiver;

    /**
     * Called when the fragment view is created
     * @param inflater The layout inflater
     * @param container The view's container
     * @param savedInstanceState The saved view state
     * @return The new fragment view
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        super.onCreateView(inflater, container, savedInstanceState);
        int fragmentLayoutId = getResources().getIdentifier("rich_inbox_fragment", "layout", inflater.getContext().getApplicationContext().getPackageName());
        int inboxLayoutId = getResources().getIdentifier("rich_inbox_layout", "id", inflater.getContext().getApplicationContext().getPackageName());

        ActionBar actionBar = getActivity().getActionBar();
        if(actionBar != null)
            actionBar.setHomeButtonEnabled(true);

        View view = inflater.inflate(fragmentLayoutId, container, false);
        setViewGroup((ViewGroup) view.findViewById(inboxLayoutId));
        setHasOptionsMenu(true);

        return view;
    }

    /**
     * Displays the fragment
     * @param fragmentManager
     */
    public void showContent(FragmentManager fragmentManager)
    {
        RichInboxListFragment richInboxListFragment = (RichInboxListFragment)fragmentManager.findFragmentById(getResources().getIdentifier("rich_inbox_list", "id", getView().getContext().getPackageName()));

        RichContent message = richInboxListFragment.getMessage(getCurrentIndex());
        if(message==null)
            return;



        Configuration config = getActivity().getResources().getConfiguration();
        if(config.isLayoutSizeAtLeast(Configuration.SCREENLAYOUT_SIZE_LARGE)) {
            // tablet interface
            richInboxListFragment.notifyDataSetChanged();
        }
        else
        {
            // phone interface
            setActionBarUp(true);
        }

        getActivity().invalidateOptionsMenu();
    }

    /**
     * Called when preparing the menu is needed
     * @param menu
     */
    @Override
    public void onPrepareOptionsMenu (Menu menu) {

    }

    /**
     * Called when the fragment starts
     */
    @Override
    public void onStart() {
        super.onStart();
    }

    /**
     * Sets the action bar state
     * @param setting true for up, false for down
     */
    public void setActionBarUp(boolean setting)
    {
        ActionBar actionBar = getActivity().getActionBar();
        if(actionBar != null)
            actionBar.setDisplayHomeAsUpEnabled(setting);
    }


    /**
     * Called when the menu is created
     * @param menu The menu
     * @param inflater The layout inflater
     */
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }

    /**
     * Called when menu option is selected
     * @param item The selected item
     * @return true for operation is done, false otherwise
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return true;
    }





}
