/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import org.json.JSONObject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import java.util.Iterator;
import java.util.Map;

import co.acoustic.mobile.push.sdk.api.MceSdk;
import co.acoustic.mobile.push.sdk.api.OperationCallback;
import co.acoustic.mobile.push.sdk.api.OperationResult;
import co.acoustic.mobile.push.sdk.api.message.MessageSync;
import co.acoustic.mobile.push.sdk.api.notification.DataMceNotificationAction;
import co.acoustic.mobile.push.sdk.api.notification.NotificationDetails;
import co.acoustic.mobile.push.sdk.notification.ActionImpl;
import co.acoustic.mobile.push.sdk.task.MceSdkTaskScheduler;
import co.acoustic.mobile.push.sdk.util.Logger;
import co.acoustic.mobile.push.sdk.wi.BaseAlarmReceiver;

/**
 * This class is the notification action that opens an inbox message
 */
public class InboxMessageAction implements DataMceNotificationAction {
    private static final String TAG = "InboxMessageAction";

    static Class richInboxActivity = null;

    /**
     * This method handles the action call
     * @param context The application context
     * @param type The notification action type
     * @param name The notification action name (can be null)
     * @param attribution The notification attribution (can be null)
     * @param mailingId The notification mailing id
     * @param payload The notification payload. The map contains the key value pairs from the notification action payload.
     * @param fromNotification true if this action is called from a notification and false otherwise
     */
    @Override
    public void handleAction(Context context, String type, String name, String attribution, String mailingId, Map<String, String> payload, boolean fromNotification) {

        final InboxMessageReference messageReference = new InboxMessageReference(
                payload.get("value"),
                payload.get(InboxMessageReference.INBOX_MESSAGE_ID_KEY));
        if (messageReference.hasReference()) {
            RichContent message = messageReference.getMessageFromDb(context);
            if (message == null) {
                InboxMessageProcessor.addMessageToLoad(messageReference);
            }
            if(richInboxActivity != null) {
                MceSdk.closeSystemDialogs(context);
                Intent intent = new Intent(context, richInboxActivity);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                messageReference.addToIntent(intent);
                context.startActivity(intent);
                if (fromNotification) {
                    InboxEvents.sendInboxNotificationOpenedEvent(context, new ActionImpl(type, name, payload), attribution, mailingId);
                }
            }
        }
    }

    /**
     * This method initiates the action
     * @param context The application's context
     * @param initOptions The initialization options
     */
    @Override
    public void init(Context context, JSONObject initOptions) {
        BaseAlarmReceiver.addRegisteredListener(InboxUpdateService.class.getName(), new InboxUpdateService());
        MceSdkTaskScheduler.startRepeatingTask(context, InboxUpdateTask.getInstance(), null, true);
        registerTemplates(initOptions);
        String inboxControlImpl = initOptions.optString("inboxControl");
        if(inboxControlImpl != null && !inboxControlImpl.isEmpty()) {
            try {
                InboxPlugin.InboxControl inboxControl = (InboxPlugin.InboxControl) Class.forName(inboxControlImpl).newInstance();
                InboxPlugin.setInboxControl(inboxControl);
            } catch (Exception e) {
                Logger.e(TAG, "Failed to apply inbox control " + inboxControlImpl, e);
            }
        }
    }

    /**
     * This method updates the action
     * @param context The application's context
     * @param updateOptions The update options
     */
    @Override
    public void update(Context context, JSONObject updateOptions) {
        registerTemplates(updateOptions);
    }

    /**
     * This method checks if inbox message is in the sdk db. If it's not, it returns false (which prevents the notification from appearing) and downloads the inbox message.
     * After the message is downloaded, the notification will be displayed
     * @param context The application's context
     * @param notificationDetails The received notification
     * @param sourceBundle The bundle that contained the notification
     * @return true if inbox message is in the db and false otherwise
     */
    @Override
    public boolean shouldDisplayNotification(final Context context, NotificationDetails notificationDetails, final Bundle sourceBundle) {
        final InboxMessageReference messageReference = new InboxMessageReference(
                notificationDetails.getAction().getPayloadValue("value"),
                notificationDetails.getAction().getPayloadValue(InboxMessageReference.INBOX_MESSAGE_ID_KEY));
        Logger.d(TAG,"Should display notification wit inbox action: "+messageReference);
        if(messageReference.hasReference()) {
            RichContent message = messageReference.getMessageFromDb(context);
            if (message == null) {
                Logger.d(TAG, "Inbox message not found");
                InboxPlugin.InboxControl inboxControl = InboxPlugin.getInboxControl();
                boolean shouldFetchMessage = true;
                try {
                    shouldFetchMessage = inboxControl.shouldFetchMessageFromAlert(messageReference.getInboxMessageId(), messageReference.getContentId());
                } catch (Throwable t) {
                    Logger.e(TAG, "inbox message fetch control failed "+messageReference.getInboxMessageId()+", "+messageReference.getContentId(), t);
                }
                if(shouldFetchMessage) {
                    InboxMessageProcessor.addMessageToLoad(messageReference);
                    MessageSync.syncMessages(context, new OperationCallback<>() {
                        @Override
                        public void onSuccess(MessageSync.SyncReport syncReport, OperationResult result) {

                        }

                        @Override
                        public void onFailure(MessageSync.SyncReport syncReport, OperationResult result) {

                        }
                    });
                }
            }
        }
        return true;
    }

    /**
     * This method is called when a with action is clicked. If it returns true, the default sdk event for action click will be sent.
     * If this action sends its own event, it should return false.
     * @param context The application's context
     * @return true to send the default click event, false otherwise
     */
    @Override
    public boolean shouldSendDefaultEvent(Context context) {
        return false;
    }

    private void registerTemplates(JSONObject options) {
        try {
            JSONObject templatesJSON = options.optJSONObject("templates");
            if(templatesJSON != null) {
                Iterator<String> templates = templatesJSON.keys();
                while(templates.hasNext()) {
                    String template = templates.next();
                    String templateClassName = templatesJSON.getString(template);
                    Class templateClass = Class.forName(templateClassName);
                    RichContentTemplate templateInstance = (RichContentTemplate)templateClass.newInstance();
                    RichContentTemplateRegistry.registerTemplate(template, templateInstance);
                }
            }
            richInboxActivity = InboxPlugin.getInboxControl().getRichInboxActivityClass();
        } catch(Throwable t) {
            Logger.e(TAG, "Failed to load templates", t);
        }
    }

    @Override
    public void clearData(Context context) {

    }
}
