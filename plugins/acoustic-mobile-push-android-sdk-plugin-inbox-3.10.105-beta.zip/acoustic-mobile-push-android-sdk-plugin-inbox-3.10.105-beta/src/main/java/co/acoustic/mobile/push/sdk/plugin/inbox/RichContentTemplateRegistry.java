/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import co.acoustic.mobile.push.sdk.util.Logger;

import java.util.HashMap;
import java.util.Map;

/**
 * This is the registry for inbox message templates
 */
public class RichContentTemplateRegistry {

   static final Map<String, RichContentTemplate> TEMPLATE_NAME_TO_TEMPLATE = new HashMap<>();

    public static final String DEFAULT_TEMPLATE_TYPE = "default";
    private static final String TAG = "RichContentTemplateRegistry";

    static {
        try {
            registerTemplate(DEFAULT_TEMPLATE_TYPE, (RichContentTemplate)Class.forName("co.acoustic.mobile.push.sdk.plugin.inbox.HtmlRichContent").newInstance());
            registerTemplate("post", (RichContentTemplate)Class.forName("co.acoustic.mobile.push.sdk.plugin.inbox.PostMessageTemplate").newInstance());
        } catch (Exception e) {
            Logger.e(TAG, "Error while registering template. Details: " + e.getMessage(), e);
        }
    }

    /**
     * Registers a template
     * @param templateName The template name
     * @param template The template
     */
    public static void registerTemplate(String templateName, RichContentTemplate template) {
        Logger.d(TAG,"Registering inbox template: "+templateName +" -> "+template);
        TEMPLATE_NAME_TO_TEMPLATE.put(templateName, template);
    }

    /**
     * Retrieves a registered template
     * @param templateName The template name
     * @return The template
     */
    public static RichContentTemplate getRegisteredTemplate(String templateName) {

        RichContentTemplate template = TEMPLATE_NAME_TO_TEMPLATE.get(templateName);
        if(template == null) {
            template = TEMPLATE_NAME_TO_TEMPLATE.get(DEFAULT_TEMPLATE_TYPE);
        }
        return template;
    }
}
