/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;


import co.acoustic.mobile.push.sdk.task.MceSdkRepeatingTask;

public class InboxUpdateTask extends MceSdkRepeatingTask {

    public InboxUpdateTask() {
        super(new InboxUpdateService(), new InboxUpdateJob());
    }

    private static final InboxUpdateTask INSTANCE = new InboxUpdateTask();

    public static InboxUpdateTask getInstance() {
        return INSTANCE;
    }
}
