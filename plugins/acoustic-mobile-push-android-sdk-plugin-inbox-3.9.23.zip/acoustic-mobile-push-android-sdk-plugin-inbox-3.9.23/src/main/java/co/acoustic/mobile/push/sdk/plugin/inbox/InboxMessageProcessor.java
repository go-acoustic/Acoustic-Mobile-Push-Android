/*
 *  Copyright © 2011, 2020 Acoustic, L.P. All rights reserved.
 *
 *  NOTICE: This file contains material that is confidential and proprietary to
 *  Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 *  industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 *  Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.
 *
 */

package co.acoustic.mobile.push.sdk.plugin.inbox;

import org.json.JSONObject;

import android.content.Context;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import co.acoustic.mobile.push.sdk.api.message.MessageProcessor;
import co.acoustic.mobile.push.sdk.util.Iso8601;
import co.acoustic.mobile.push.sdk.util.Logger;

public class InboxMessageProcessor implements MessageProcessor<RichContent> {

    private static final String TAG = "InboxMessageProcessor";

    private static final Set<String> MESSAGE_IDS_TO_LOAD = new HashSet<String>();
    private static final Set<String> CONTENT_IDS_TO_LOAD = new HashSet<String>();

    @Override
    public void init(Context context, JSONObject initOptions) {

    }

    @Override
    public ProcessReport<RichContent> process(Context context, List<RichContent> messages) {
        boolean updated = false;
        List<RichContent> newMessages = new LinkedList<>();
        for(RichContent message : messages) {
            MessageProcessStatus messageProcessStatus = processMessage(context, message);
            if(!MessageProcessStatus.ignored.equals(messageProcessStatus)) {
                updated = true;
                if (MessageProcessStatus.added.equals(messageProcessStatus)) {
                    newMessages.add(message);
                }
            }
        }
        return new Report(this, newMessages, updated);
    }

    @Override
    public boolean sendStatusUpdates(Context context, boolean inNewThread) {
        if(!inNewThread) {
            return InboxMessagesClient.INBOX_UPDATE_STATE.sendUpdates(context);
        } else {
            InboxMessagesClient.INBOX_UPDATE_STATE.sendUpdatesThroughExecutor(context);
            return true;
        }
    }

    protected MessageProcessStatus processMessage(Context context, RichContent message) {
        RichContent currentMessage = InboxMessagesClient.getInboxMessageByMessageId(context, message.getMessageId());
        if(currentMessage == null) {
            if(!message.getIsDeleted()) {
                processNewMessage(context, message);
                return MessageProcessStatus.added;
            } else {
                return MessageProcessStatus.ignored;
            }
        } else {
            processUpdatedMessage(context, currentMessage, message);
            return MessageProcessStatus.updated;
        }
    }

    protected void processNewMessage(Context context, RichContent message) {
        RichContentDatabaseHelper.getRichContentDatabaseHelper(context).insertMessage(message);
    }

    protected void processUpdatedMessage(Context context, RichContent currentMessage, RichContent updatedMessage) {
        if(updatedMessage.getIsDeleted() && !currentMessage.getIsDeleted()) {
            RichContentDatabaseHelper.getRichContentDatabaseHelper(context).deleteMessage(currentMessage);
        }
        if(updatedMessage.getIsRead() && !currentMessage.getIsRead()) {
            RichContentDatabaseHelper.getRichContentDatabaseHelper(context).setMessageRead(currentMessage);
        }
        if(!updatedMessage.getIsRead() && currentMessage.getIsRead()) {
            RichContentDatabaseHelper.getRichContentDatabaseHelper(context).setMessageUnread(currentMessage);
        }
    }

    @Override
    public RichContent createMessage(Context context, JSONObject messageJSON) {
        try {
            String messageId = messageJSON.getString("inboxMessageId");
            boolean isDeleted = messageJSON.getBoolean("isDeleted");
            boolean isRead = messageJSON.getBoolean("isRead");

            RichContent rc = new RichContent();

            rc.setMessageId(messageId);
            rc.setIsRead(isRead);
            rc.setIsDeleted(isDeleted);

            if (!isDeleted) {
                rc.setContentId(messageJSON.getString("richContentId"));
                rc.setAttribution(messageJSON.getString("attribution"));
                rc.setTemplate(messageJSON.getString("template"));
                rc.setSendDate(Iso8601.toDate(messageJSON.getString("sendDate")));
                rc.setExpirationDate(Iso8601.toDate(messageJSON.getString("expirationDate")));
                rc.setContent(messageJSON.getJSONObject("content"));
            } else {
                Logger.v(TAG, "Parsed deleted message " + messageJSON);
            }
            return rc;

        } catch (Exception e) {
            Logger.e(TAG, "Failed to load inbox message "+messageJSON, e);
            return null;
        }
    }

    @Override
    public String getMessageToLoad(Context context) {
        return getSingleMessageToLoad();
    }

    @Override
    public void clearMessageToLoad(Context context) {
        clearMessagesToLoad();
    }

    public static void addMessageToLoad(InboxMessageReference reference) {
        if(reference.getInboxMessageId() != null) {
            synchronized (MESSAGE_IDS_TO_LOAD) {
                MESSAGE_IDS_TO_LOAD.add(reference.getInboxMessageId());
            }
        } else if(reference.getContentId() != null){
            synchronized (MESSAGE_IDS_TO_LOAD) {
                CONTENT_IDS_TO_LOAD.add(reference.getContentId());
            }
        }
    }

    private static void clearMessagesToLoad() {
        synchronized (MESSAGE_IDS_TO_LOAD) {
            MESSAGE_IDS_TO_LOAD.clear();
            CONTENT_IDS_TO_LOAD.clear();
        }
    }

    private static String getSingleMessageToLoad() {
        synchronized (MESSAGE_IDS_TO_LOAD) {
            if(MESSAGE_IDS_TO_LOAD.size() == 1 && CONTENT_IDS_TO_LOAD.isEmpty()) {
                return MESSAGE_IDS_TO_LOAD.iterator().next();
            } else {
                return null;
            }
        }
    }

    static enum  MessageProcessStatus {
        added, updated, ignored
    }

    public static class Report extends ProcessReport<RichContent> {
        public Report(InboxMessageProcessor source, List<RichContent> newMessages, boolean updated) {
            super(source, newMessages, updated);
        }
    }
}
