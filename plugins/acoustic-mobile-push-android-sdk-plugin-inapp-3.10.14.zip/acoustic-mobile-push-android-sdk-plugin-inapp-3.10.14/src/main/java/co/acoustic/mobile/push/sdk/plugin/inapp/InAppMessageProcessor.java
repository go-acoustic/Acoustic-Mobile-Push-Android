/*
 *  Copyright © 2011, 2020 Acoustic, L.P. All rights reserved.
 *
 *  NOTICE: This file contains material that is confidential and proprietary to
 *  Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 *  industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 *  Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.
 *
 */

package co.acoustic.mobile.push.sdk.plugin.inapp;

import android.content.Context;

import org.json.JSONObject;

import java.io.IOException;
import java.util.List;

import co.acoustic.mobile.push.sdk.api.message.MessageProcessor;
import co.acoustic.mobile.push.sdk.plugin.Plugin;
import co.acoustic.mobile.push.sdk.plugin.PluginRegistry;
import co.acoustic.mobile.push.sdk.util.Logger;

public class InAppMessageProcessor implements MessageProcessor<InAppPayload> {

    private static final String TAG = "InAppMessageProcessor";

    @Override
    public void init(Context context, JSONObject initOptions) {
        PluginRegistry.registerPlugin("inApp", new InAppPlugin());
    }

    @Override
    public ProcessReport<InAppPayload> process(Context context, List<InAppPayload> messages) {
        for(InAppPayload message : messages) {
            processInAppMessage(context, message);
        }
        return new Report(this, messages, !messages.isEmpty());
    }

    protected void processInAppMessage(Context context, InAppPayload message) {
        try {
            InAppStorage.update(context, message, true);
        } catch (IOException ioe) {
            Logger.e(TAG,"Failed to update inApp message "+message, ioe);
        }
    }

    @Override
    public InAppPayload createMessage(Context context, JSONObject messageJson) {
        try {
            return InAppPayloadJsonTemplate.INSTANCE.fromJSON(messageJson);
        } catch (Exception e) {
            Logger.e(TAG, "Failed to load inapp message "+messageJson, e);
            return null;
        }
    }

    @Override
    public boolean sendStatusUpdates(Context context, boolean inNewThread) {
        Plugin inAppPlugin = PluginRegistry.getRegisteredPlugin("inApp");
        if(inAppPlugin != null) {
            return inAppPlugin.sendStatusUpdates(context, inNewThread);
        } else {
            return true;
        }
    }

    @Override
    public String getMessageToLoad(Context context) {
        return null;
    }

    @Override
    public void clearMessageToLoad(Context context) {

    }

    public static class Report extends ProcessReport<InAppPayload> {
        public Report(InAppMessageProcessor source, List<InAppPayload> newMessages, boolean updated) {
            super(source, newMessages, updated);
        }
    }
}
