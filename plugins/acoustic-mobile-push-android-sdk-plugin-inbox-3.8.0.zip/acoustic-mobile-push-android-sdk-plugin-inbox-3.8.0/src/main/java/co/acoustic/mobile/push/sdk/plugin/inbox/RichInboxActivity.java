/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.app.Activity;
import android.os.Bundle;
import android.os.PersistableBundle;

/**
 * This is the inbox activity class
 */
public class RichInboxActivity extends Activity {
   private long id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        updateId(savedInstanceState);

        setContentView(getResources().getIdentifier("rich_inbox_activity", "layout", getPackageName()));
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        updateId(savedInstanceState);
    }

    /**
     * Called when the activity is restored
     * @param savedInstanceState The activity's saved state
     * @param persistentState The persistent sttate
     */
    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState, PersistableBundle persistentState) {
        super.onRestoreInstanceState(savedInstanceState, persistentState);
        updateId(savedInstanceState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        storeId(outState);
    }

    /**
     * Called when the activity state is saved
     * @param outState The activity state
     * @param outPersistentState The persistent state
     */
    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        storeId(outState);
    }

    /**
     * Retrieves the activity's id
     * @return The id
     */
    public long getId() {
        return id;
    }

    private void updateId(Bundle savedInstanceState) {
        if(savedInstanceState == null || !savedInstanceState.containsKey("inboxActivityId")) {
            id = System.currentTimeMillis();
        } else {
            id = savedInstanceState.getLong("inboxActivityId");
        }
    }

    private void storeId(Bundle outState) {
        outState.putLong("inboxActivityId", id);
    }
}