/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.content.Intent;
import android.net.Uri;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import co.acoustic.mobile.push.sdk.api.notification.Action;
import co.acoustic.mobile.push.sdk.api.notification.MceNotificationAction;
import co.acoustic.mobile.push.sdk.api.notification.MceNotificationActionRegistry;
import co.acoustic.mobile.push.sdk.notification.ActionImpl;
import co.acoustic.mobile.push.sdk.util.Logger;

import java.util.HashMap;
import java.util.Map;

/**
 * This class is the inbox message display implementation for html template
 */
public class HtmlInboxMessageDisplay implements InboxMessageDisplay {

   private static final String TAG = "HtmlInboxMessageDisplay";

    /**
     * Displays the html message
     * @param message The rich content
     * @param activity The containing activity
     */
    @Override
    public void displayMessage(final RichContent message, final InboxMessageActivity activity) {
        activity.setTheme(android.R.style.Theme_Holo);
        int layoutId = activity.getResources().getIdentifier("inbox_message_activity", "layout", activity.getPackageName());
        activity.setContentView(layoutId);
        int webViewId = activity.getResources().getIdentifier("webView", "id", activity.getPackageName());
        WebView webView = (WebView) activity.findViewById(webViewId);
        WebSettings settings = webView.getSettings();
        settings.setDefaultTextEncodingName("utf-8");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                try {
                    Uri uri = Uri.parse(url);
                    String scheme = uri.getScheme();
                    if (scheme.equalsIgnoreCase("actionid")) {
                        String actionId = uri.getSchemeSpecificPart();
                        Action action = message.getAction(actionId);
                        if (action != null) {
                            MceNotificationAction actionImpl = MceNotificationActionRegistry.getNotificationAction(action.getType());
                            if (actionImpl != null) {
                                Map<String, String> payload = new HashMap<String, String>();
                                for (String key : action.getPayloadKeys()) {
                                    payload.put(key, action.getPayloadValue(key));
                                }
                                actionImpl.handleAction(view.getContext().getApplicationContext(), action.getType(), action.getType(), message.getAttribution(), null, payload, false);
                                InboxEvents.sendInboxMessageActionTakenEvent(view.getContext().getApplicationContext(), message, action);
                            }
                        }

                        return true;
                    } else {
                        String type = "url";
                        String value = url;
                        if (scheme.equalsIgnoreCase("tel")) {
                            type = "dial";
                            value = uri.getSchemeSpecificPart();
                        }

                        MceNotificationAction actionImpl = MceNotificationActionRegistry.getNotificationAction(type);
                        if (actionImpl != null) {
                            Map<String, String> payload = new HashMap<String, String>();
                            payload.put("value", value);
                            Action action = new ActionImpl(type, type, payload);
                            InboxEvents.sendInboxMessageActionTakenEvent(view.getContext().getApplicationContext(), message, action);
                        }
                    }

                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    activity.startActivity(intent);

                    return true;
                } catch (Throwable t) {
                    Logger.e(TAG, "Failed shouldOverrideUrlLoading", t);
                    return false;
                }
            }


            @Override
            public void onPageFinished(WebView view, String url) {
                try {
                    super.onPageFinished(view, url);
                    String title = view.getTitle();
                    if (title != null && title.length() > 0 && !title.startsWith("data:text/html") && !title.equals("about:blank")) {
                        activity.setTitle(title);
                    } else {
                        activity.setTitle(message.getSubject());
                    }
                } catch (Throwable t) {
                    Logger.e(TAG, "Failed onPageFinished", t);
                }
            }
        });
        String richContent = message.getRichContent();
        if(richContent != null) {
            webView.loadDataWithBaseURL(null, richContent, "text/html; charset=utf-8", "UTF-8", null);
        }
    }

    /**
     * THis method is called when the view is hidden
     * @param message The rich content in the view
     * @param activityId The id of the containing activity
     */
    @Override
    public void viewHidden(RichContent message, long activityId) {

    }
}
