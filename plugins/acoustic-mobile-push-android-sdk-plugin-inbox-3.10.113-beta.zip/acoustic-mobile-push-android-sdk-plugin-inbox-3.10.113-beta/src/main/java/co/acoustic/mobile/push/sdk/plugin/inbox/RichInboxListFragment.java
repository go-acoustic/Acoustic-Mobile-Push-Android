/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.annotation.SuppressLint;
import android.app.FragmentManager;
import android.app.ListFragment;
import android.app.LoaderManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.Loader;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CursorAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import co.acoustic.mobile.push.sdk.api.OperationCallback;
import co.acoustic.mobile.push.sdk.api.OperationResult;
import co.acoustic.mobile.push.sdk.api.db.SdkDatabaseCursor;
import co.acoustic.mobile.push.sdk.api.message.MessageSync;
import co.acoustic.mobile.push.sdk.util.Logger;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This is the fragment for the inbox messages preview
 */
public class RichInboxListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<SdkDatabaseCursor> {
    private static final String TAG = "RichInboxListFragment";

    private final BroadcastReceiver inboxUpdaterReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            RichInboxListFragment.this.getActivity().runOnUiThread(() -> getLoaderManager().restartLoader(0, null, RichInboxListFragment.this));
        }
    };

    /**
     * Retrieves the number of messages
     * @return The number of messages
     */
    public Integer getCount()
    {
        MessageCursorAdapter cursorAdapter = (MessageCursorAdapter)getListAdapter();
        if(cursorAdapter==null)
            return null;

        return cursorAdapter.getCount();
    }

    /**
     * This method is called when a message preview is clicked
     * @param l The containing list view
     * @param v The containing view
     * @param position The click position
     * @param id The preview id
     */
    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        try {

            super.onListItemClick(l, v, position, id);
            showMessage(position, true);

            Configuration config = getActivity().getResources().getConfiguration();
            if (!config.isLayoutSizeAtLeast(Configuration.SCREENLAYOUT_SIZE_LARGE)) {
                // Phone interface
                getActivity().invalidateOptionsMenu();
            }
        } catch (Throwable t) {
            Logger.e(TAG, "Failed onListItemClicked", t);
        }
    }

    private void showMessage(InboxMessageReference messageReference) {
        Date lastDate= new Date(0);
        int lastMessageIndex = -1;
        for(int i = 0; i < getCount() ; ++i) {
            RichContent message = getMessage(i);
            if(messageReference.isReferencedMessage(message) && message.getSendDate().after(lastDate)) {
                lastMessageIndex = i;
                lastDate=message.getSendDate();
            }
        }
        if(lastMessageIndex != -1) {
            showMessage(lastMessageIndex, false);
        }
    }

    private void showMessage(int position, boolean fromList) {

        if(!InboxPlugin.shouldDisplayInboxMessage(getMessage(position)))
        {
            Toast.makeText(getActivity(), "Message has been expired", Toast.LENGTH_SHORT).show();
            return;
        }
        List<RichContent> messages = new ArrayList<>(getCount());
        for(int i = 0; i < getCount() ; ++i) {
            messages.add(getMessage(i));
        }
        try {
            Intent intent = new Intent(getView().getContext().getApplicationContext(), InboxMessageDisplayActivity.class);
            intent.putExtra("messages", InboxMessageDisplayActivity.getInboxMessageAsJSONArray(messages).toString());
            intent.putExtra("index", position);
            intent.putExtra("activityId", ((RichInboxActivity)getActivity()).getId());
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getView().getContext().getApplicationContext().startActivity(intent);
            InboxEvents.sendInboxMessageOpenedEvent(getView().getContext().getApplicationContext(), getMessage(position));
        } catch(JSONException e) {
            Logger.e(TAG, "Failed to open message", e);
        }
    }

    private RichInboxFragment getRichInboxFragment() {
        return (RichInboxFragment) (getParentFragment().getFragmentManager().findFragmentById(getResources().getIdentifier("rich_inbox_fragment", "id", getView().getContext().getPackageName())));
    }

    /**
     * Gets an inbox message
     * @param index The message index
     * @return The message
     */
    public RichContent getMessage(int index)
    {
        ListAdapter adapter = getListAdapter();
        int count = adapter.getCount();

        // Bounds check
        if(index > count-1)
            return null;

        if(index < 0)
            return null;

        RichContentDatabaseHelper.MessageCursor messageCursor = (RichContentDatabaseHelper.MessageCursor) adapter.getItem(index);
        return messageCursor.getRichContent();
    }

    void restartLoader()
    {
        getLoaderManager().restartLoader(0, null, this);
    }

    void notifyDataSetChanged()
    {
        MessageCursorAdapter cursorAdapter = (MessageCursorAdapter)getListAdapter();
        cursorAdapter.notifyDataSetChanged();
    }

    /**
     * This method is called when the fragment is resumed
     */
    @Override
    public void onResume() {
        super.onResume();
        MessageSync.syncMessages(getActivity().getApplicationContext(), new OperationCallback<>() {
            @SuppressLint("UnspecifiedRegisterReceiverFlag")
            @Override
            public void onSuccess(MessageSync.SyncReport syncReport, OperationResult result) {
                RichInboxListFragment.this.getActivity().runOnUiThread(() -> getLoaderManager().restartLoader(0, null, RichInboxListFragment.this));

                final IntentFilter filter = new IntentFilter(InboxMessagesClient.INBOX_UPDATE_ACTION);

                // Use ContextCompat to ensure compatibility with older API levels, RECEIVER_EXPORTED is required for API > 33
                if (Build.VERSION.SDK_INT > Build.VERSION_CODES.TIRAMISU) {
                    ContextCompat.registerReceiver(getActivity(), inboxUpdaterReceiver, filter, ContextCompat.RECEIVER_EXPORTED);
                } else {
                    getActivity().registerReceiver(inboxUpdaterReceiver, filter);
                }

                getListView().setOnScrollListener(new AbsListView.OnScrollListener() {

                    private int firstVisiblePosition = -1;
                    private int lastVisiblePosition = -1;

                    @Override
                    public void onScrollStateChanged(AbsListView view, int scrollState) {

                    }

                    @Override
                    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
                        int newFirstVisiblePosition = view.getFirstVisiblePosition();
                        int newLastVisiblePosition = view.getLastVisiblePosition();
                        if (firstVisiblePosition != -1 && lastVisiblePosition != -1) {
                            for (int i = firstVisiblePosition; i < newFirstVisiblePosition; ++i) {
                                RichContent message = getMessage(i);
                                if (message != null) {
                                    RichContentTemplateRegistry.getRegisteredTemplate(message.getTemplate()).getPreviewFragment().viewHidden(message, ((RichInboxActivity) getActivity()).getId());
                                }
                            }
                            for (int i = lastVisiblePosition; i > newLastVisiblePosition; --i) {
                                RichContent message = getMessage(i);
                                if (message != null) {
                                    RichContentTemplateRegistry.getRegisteredTemplate(message.getTemplate()).getPreviewFragment().viewHidden(message, ((RichInboxActivity) getActivity()).getId());
                                }
                            }
                        }
                        firstVisiblePosition = newFirstVisiblePosition;
                        lastVisiblePosition = newLastVisiblePosition;

                    }
                });
            }

            @Override
            public void onFailure(MessageSync.SyncReport syncReport, OperationResult result) {

            }
        } );

    }

    private void viewHidden() {
        for(int i=0; i<getCount();++i) {
            RichContent message = getMessage(i);
            RichContentTemplateRegistry.getRegisteredTemplate(message.getTemplate()).getPreviewFragment().viewHidden(message, ((RichInboxActivity) getActivity()).getId());
        }
    }

    /**
     * This method is called when the state of the fragment is saved
     */
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        try {
            viewHidden();
        } catch (Throwable t) {
            Logger.e(TAG, "Error while reading view to be hidden. Details: " + t.getMessage(), t);
        }
    }

    /**
     * This method is called when the fragment is paused
     */
    @Override
    public void onPause() {
        super.onPause();
        try {
            getActivity().unregisterReceiver(inboxUpdaterReceiver);
        } catch (Throwable t) {
            Logger.e(TAG, "Error while unregistering receiver. Details: " + t.getMessage(), t);
        }
    }

    /**
     * This method is called when the fragment starts
     */
    @Override
    public void onStart()
    {
        getLoaderManager().restartLoader(0, null, this);
        getListView().setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        getListView().setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() {
            @Override
            public void onItemCheckedStateChanged(ActionMode actionMode, int i, long l, boolean b) {
                // required but not needed in implementation
            }

            @Override
            public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
                MenuInflater inflater = actionMode.getMenuInflater();
                inflater.inflate(getResources().getIdentifier("rich_inbox_context", "menu", getView().getContext().getPackageName()), menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
                // required but not needed in implementation
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
                int id = menuItem.getItemId();
                if(getResources().getIdentifier("delete_message", "id", getView().getContext().getPackageName()) == id) {
                    MessageCursorAdapter cursorAdapter = (MessageCursorAdapter) getListAdapter();

                    for (int i = cursorAdapter.getCount() - 1; i >= 0; i--) {
                        if (getListView().isItemChecked(i)) {
                            RichContent message = getMessage(i);
                            InboxMessagesClient.deleteMessage(getView().getContext(), message);
                        }
                    }
                    actionMode.finish();
                    getLoaderManager().restartLoader(0, null, RichInboxListFragment.this);
                    return true;
                } else {
                    return false;
                }

            }

            @Override
            public void onDestroyActionMode(ActionMode actionMode) {
                // required but not needed in implementation
            }
        });
        super.onStart();
    }

    /**
     * This method is called when the containg activity receives a result
     * @param requestCode The request code
     * @param resultCode The result code
     * @param data The data's intent
     */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        getLoaderManager().restartLoader(0, null, null);
    }

    /**
     * This method is called when the containg activity is created
     * @param savedInstanceState The activity saved state
     */
    @Override
    public void onActivityCreated(Bundle savedInstanceState)
    {
        getLoaderManager().initLoader(0, null, this);
        super.onActivityCreated(savedInstanceState);
    }

    /**
     * This method is called when the loader is created
     * @param id The loader id
     * @param args The loader arguments
     * @return The new loader
     */
    @Override
    public Loader<SdkDatabaseCursor> onCreateLoader(int id, Bundle args)
    {
        return new RichInboxCursorLoader(getActivity());
    }

    /**
     * This method is called when loading is done
     * @param loader The loader
     * @param cursor The cursor
     */
    @Override
    public void onLoadFinished(Loader<SdkDatabaseCursor> loader, SdkDatabaseCursor cursor)
    {
        try {
            FragmentManager fragmentManager = getFragmentManager();

            RichInboxFragment richInboxFragment = null;
            if (fragmentManager != null) {
                richInboxFragment = (RichInboxFragment) fragmentManager.findFragmentById(getResources().getIdentifier("rich_inbox_fragment", "id", getView().getContext().getPackageName()));
            }
            if (richInboxFragment == null) {
                richInboxFragment = this.getRichInboxFragment();
            }
            MessageCursorAdapter adapter = new MessageCursorAdapter(getActivity(),
                    (RichContentDatabaseHelper.MessageCursor) cursor, richInboxFragment);
            setListAdapter(adapter);
            setEmptyText("No messages");

            // tablet interface
            Configuration config = getActivity().getResources().getConfiguration();
            if (config.isLayoutSizeAtLeast(Configuration.SCREENLAYOUT_SIZE_LARGE)) {
                richInboxFragment.showContent(fragmentManager);
            }
            Intent intent = getActivity().getIntent();
            if (intent != null) {
                InboxMessageReference messageReference = new InboxMessageReference(intent);
                if (messageReference.hasReference()) {
                    messageReference.removeFromIntent(intent);
                    showMessage(messageReference);
                }
            }
        } catch (Throwable t) {
            Logger.e(TAG, "Failed load finished", t);
        }
    }

    /**
     * This method is called when the loader resets
     */
    @Override
    public void onLoaderReset(Loader<SdkDatabaseCursor> loader)
    {
        setListAdapter(null);
    }

    static class MessageCursorAdapter extends CursorAdapter
    {
        private final RichContentDatabaseHelper.MessageCursor messageCursor;
        private final Context context;
        private final boolean isTablet;
        final RichInboxFragment richInboxFragment;
        private InboxMessagePreviewFragment previewFragment;
        private final long activityId;

        public RichContentDatabaseHelper.MessageCursor getMessageCursor() {
            return messageCursor;
        }

        public boolean isTablet() {
            return isTablet;
        }

        public Context getContext() {
            return context;
        }

        public RichInboxFragment getRichInboxFragment() {
            return richInboxFragment;
        }

        public long getActivityId() {
            return activityId;
        }

        public MessageCursorAdapter(Context context, RichContentDatabaseHelper.MessageCursor cursor,
                                    RichInboxFragment richInboxFragment) {
            super(context, cursor, 0);
            this.richInboxFragment = richInboxFragment;
            this.context = context;
            messageCursor = cursor;

            Configuration config = this.context.getResources().getConfiguration();
            isTablet = config.isLayoutSizeAtLeast(Configuration.SCREENLAYOUT_SIZE_LARGE);
            activityId = ((RichInboxActivity)context).getId();
        }

        @Override
        public int getViewTypeCount() {
            return Math.max(1,messageCursor.getCount());
        }

        @Override
        public int getItemViewType(int position) {
            return position;
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            previewFragment = RichContentTemplateRegistry.getRegisteredTemplate(getMessageCursor().getRichContent().getTemplate()).getPreviewFragment();
            View view = previewFragment.newView(this, context, cursor, parent);
            if(!InboxPlugin.shouldDisplayInboxMessage(getMessageCursor().getRichContent())) {
                view.setVisibility(View.GONE);
            }
            return view;
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor)
        {
            previewFragment = RichContentTemplateRegistry.getRegisteredTemplate(getMessageCursor().getRichContent().getTemplate()).getPreviewFragment();
            previewFragment.bindView(this, view, context, cursor);
        }
    }
}
