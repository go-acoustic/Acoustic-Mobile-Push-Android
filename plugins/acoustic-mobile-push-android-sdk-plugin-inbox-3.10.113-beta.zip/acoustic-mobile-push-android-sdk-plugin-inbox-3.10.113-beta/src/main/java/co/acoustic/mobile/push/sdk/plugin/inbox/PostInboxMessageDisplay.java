/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.view.View;

import co.acoustic.mobile.push.sdk.util.Logger;

import org.json.JSONException;

/**
 * This is the post template display implementation
 */
public class PostInboxMessageDisplay implements InboxMessageDisplay {

   private static final String TAG = "PostInboxMessageDisplay";

    /**
     * Displays the post message
     * @param message The rich content
     * @param activity The containing activity
     */
    @Override
    public void displayMessage(RichContent message, InboxMessageActivity activity) {
        try {
            PostMessageTemplate.PostMessage postMessage = new PostMessageTemplate.PostMessage(message);


            String layoutName = "post_full_layout";
            if(postMessage.getContentText() != null && postMessage.getContentImage() != null) {
                layoutName = "post_full_text_image_layout";
            }  else if(postMessage.getContentText() != null && postMessage.getContentVideo() != null) {
                layoutName = "post_full_text_video_layout";
            } else if(postMessage.getContentText() == null && postMessage.getContentImage() != null) {
                layoutName = "post_full_image_layout";
            } else if(postMessage.getContentText() == null && postMessage.getContentVideo() != null) {
                layoutName = "post_full_video_layout";
            } else if(postMessage.getContentText() != null) {
                layoutName = "post_full_text_layout";
            }

            activity.setContentView(activity.getResources().getIdentifier(layoutName, "layout", activity.getPackageName()));
            View view = activity.getWindow().getDecorView();

            PostMessageTemplate.updateHeaderView(activity, activity, view , postMessage);
            PostMessageTemplate.updateContentTextView(activity, view, postMessage);
            PostMessageTemplate.updateContentImageView(activity, activity, view, postMessage);
            PostMessageTemplate.updateContentVideoView(activity, activity.getActivityId(), view , postMessage);
            PostMessageTemplate.updateButtons(activity, view, postMessage, message);
            activity.setTitle(postMessage.getHeader());

        } catch(JSONException e) {
            Logger.e(TAG, "Failed to update message view", e);
        }
    }

    /**
     * THis method is called when the view is hidden
     * @param message The rich content in the view
     * @param activityId The id of the containing activity
     */
    @Override
    public void viewHidden(RichContent message, long activityId) {
        if(message.getTemplate().equals("post")) {
            try {
                PostMessageTemplate.PostMessage postMessage = new PostMessageTemplate.PostMessage(message);
                if(postMessage.getContentVideo() != null) {
                    PostMessageTemplate.setHidden(postMessage.getContentVideo(), activityId);
                }
            } catch (Exception e) {
                Logger.e(TAG, "Error while reading view to be hidden. Details: " + e.getMessage(), e);
            }
        }
    }
}
