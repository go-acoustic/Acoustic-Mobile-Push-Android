/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import androidx.appcompat.app.AppCompatActivity;

/**
 * This class is the base class for inbox message display activity
 */
public abstract class InboxMessageActivity extends AppCompatActivity {
    protected long activityId;

    /**
     * Retrieves the activity id
     * @return The activity id
     */
    public long getActivityId() {
        return activityId;
    }
}
