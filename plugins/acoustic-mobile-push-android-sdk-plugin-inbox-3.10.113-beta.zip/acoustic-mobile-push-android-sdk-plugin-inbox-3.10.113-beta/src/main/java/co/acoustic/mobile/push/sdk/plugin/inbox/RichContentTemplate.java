/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

/**
 * This is the implementation of an inbox message template
 */
public interface RichContentTemplate {

   /**
     * Retrieves the relevant preview fragment implementation
     * @return The template preview fragment implementation
     */
   InboxMessagePreviewFragment getPreviewFragment();

    /**
     * Retrieves the relevant message display implementation
     * @return The template message display implementation
     */
    InboxMessageDisplay getInboxMessageDisplay();

}
