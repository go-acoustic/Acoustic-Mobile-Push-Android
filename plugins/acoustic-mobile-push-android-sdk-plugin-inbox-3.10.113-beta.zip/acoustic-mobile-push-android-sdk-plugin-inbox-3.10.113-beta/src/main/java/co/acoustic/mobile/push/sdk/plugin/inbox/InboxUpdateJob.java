/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */

package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.app.job.JobParameters;
import android.content.Context;

import co.acoustic.mobile.push.sdk.api.MceSdk;
import co.acoustic.mobile.push.sdk.api.SdkState;
import co.acoustic.mobile.push.sdk.job.MceJobService;
import co.acoustic.mobile.push.sdk.job.MceSdkRepeatingJob;
import co.acoustic.mobile.push.sdk.util.Logger;

public class InboxUpdateJob implements MceSdkRepeatingJob<Object> {

    private static final String TAG = "InboxUpdateJob";

    public InboxUpdateJob() {
    }

    @Override
    public long getRepeatingInterval(Context context) {
        return 12L*60L*60L*1000L;
    }

    @Override
    public boolean startJob(Context context, MceJobService mceJobService, Object parameters, JobParameters jobParameters, String jobId) {
        SdkState sdkState = MceSdk.getRegistrationClient().getSdkState(context);
        if(SdkState.REGISTERED.equals(sdkState)) {
            Logger.d(TAG, "Starting inbox update from job");
            InboxUpdateService.runInboxUpdate(context);
        }
        mceJobService.reportJobFinished(jobParameters, parameters, this, jobId, -1, true);
        return true;
    }

    @Override
    public void endJob(MceJobService mceJobService, Object parameters) {

    }

    @Override
    public boolean isThreaded() {
        return true;
    }
}
