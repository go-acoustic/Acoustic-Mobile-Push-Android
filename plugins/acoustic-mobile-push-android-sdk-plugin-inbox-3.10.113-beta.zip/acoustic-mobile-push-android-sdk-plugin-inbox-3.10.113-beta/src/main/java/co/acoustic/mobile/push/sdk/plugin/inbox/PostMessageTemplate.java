/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;


import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.text.TextUtils;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;

import co.acoustic.mobile.push.sdk.api.MediaManager;
import co.acoustic.mobile.push.sdk.api.notification.Action;
import co.acoustic.mobile.push.sdk.api.notification.MceNotificationAction;
import co.acoustic.mobile.push.sdk.api.notification.MceNotificationActionRegistry;
import co.acoustic.mobile.push.sdk.notification.ActionImpl;
import co.acoustic.mobile.push.sdk.util.Logger;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * This is the implementation of the post template
 */
public class PostMessageTemplate implements RichContentTemplate {




    private static final String TAG = "PostMessageTemplate";

    private static final Map<Long, Map<String, VideoController>> ACTIVITY_ID_TO_VIDEO_CACHE = new HashMap<>();
    private static VideoController currentlyPlaying;



    private static void setVideoController(long activityId, String url, TextureView videoView, ImageView videoLayover, Context context) {
        synchronized (ACTIVITY_ID_TO_VIDEO_CACHE) {
            Map<String, VideoController> videoCache = null;
            if(activityId > 0) {
                videoCache = ACTIVITY_ID_TO_VIDEO_CACHE.get(activityId);
                if (videoCache == null) {
                    ACTIVITY_ID_TO_VIDEO_CACHE.clear();
                    videoCache = new HashMap<>();
                    ACTIVITY_ID_TO_VIDEO_CACHE.put(activityId, videoCache);
                }
            } else{
                if(ACTIVITY_ID_TO_VIDEO_CACHE.isEmpty()) {
                    videoCache = ACTIVITY_ID_TO_VIDEO_CACHE.values().iterator().next();
                }
            }
            if(videoCache != null) {
                VideoController controller = videoCache.get(url);
                if (controller == null) {
                    VideoController controler = new VideoController(url, videoView, videoLayover, context);
                    videoCache.put(url, controler);
                } else {
                    controller.updateVideoView(videoView, videoLayover, context);
                }
            }
        }
    }

    /**
     * Retrieves the relevant preview fragment implementation
     * @return The post preview fragment implementation
     */
    @Override
    public InboxMessagePreviewFragment getPreviewFragment() {
        return new PostMessagePreviewFragment();
    }

    /**
     * Retrieves the relevant message display implementation
     * @return The post message display implementation
     */
    @Override
    public InboxMessageDisplay getInboxMessageDisplay() {
        return new PostInboxMessageDisplay();
    }

    public static void updateHeaderView(Context context, Activity activity, View view, PostMessage postMessage) {
        TextView headerTitleView =(TextView) view.findViewById(context.getResources().getIdentifier("headerTitle", "id", context.getPackageName()));
        TextView subHeaderView = (TextView) view.findViewById(context.getResources().getIdentifier("subHeader", "id", context.getPackageName()));

        headerTitleView.setText(postMessage.getHeader());
        subHeaderView.setText(postMessage.getSubHeader());
        if(postMessage.getHeaderImage() != null) {
            ImageView headerIconView = (ImageView) view.findViewById(context.getResources().getIdentifier("headerIcon", "id", context.getPackageName()));
            headerIconView.setVisibility(View.VISIBLE);
            MediaManager.setImage(postMessage.getHeaderImage(), headerIconView, activity);
        }
    }

    public static void updateHeaderViewState(Context context, Activity activity, View view, boolean read, boolean disabled) {
        TextView headerTitleView =(TextView) view.findViewById(context.getResources().getIdentifier("headerTitle", "id", context.getPackageName()));
        TextView subHeaderView = (TextView) view.findViewById(context.getResources().getIdentifier("subHeader", "id", context.getPackageName()));

        Typeface typeface = Typeface.defaultFromStyle(Typeface.BOLD);
        TypedArray textColor = context.getTheme().obtainStyledAttributes(new int[] {android.R.attr.textColor});
        int color = textColor.getColor(0, 0);
        if(read) {
            typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
        }
        if(disabled) {
            typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
            textColor = context.getTheme().obtainStyledAttributes(new int[] {android.R.attr.textColorPrimaryDisableOnly});
            color = textColor.getColor(0, 0);
        }

        headerTitleView.setTextColor(color);
        headerTitleView.setTypeface(typeface);

        subHeaderView.setTextColor(color);
        subHeaderView.setTypeface(typeface);

    }




    static TextView updateContentTextView(Context context, View view, PostMessage postMessage) {
        if(postMessage.getContentText() != null) {
            TextView textView =(TextView) view.findViewById(context.getResources().getIdentifier("text", "id", context.getPackageName()));
            textView.setText(postMessage.getContentText());
            textView.setVisibility(View.VISIBLE);
            return textView;
        } else {
            return null;
        }
    }

    static boolean updateContentImageView(Context context, Activity activity, View view, PostMessage postMessage) {
        if(postMessage.getContentImage() != null) {
            ImageView imageView = (ImageView) view.findViewById(context.getResources().getIdentifier("img", "id", context.getPackageName()));
            MediaManager.setImage(postMessage.getContentImage(), imageView, activity);
            imageView.setVisibility(View.VISIBLE);
            return true;
        } else {
            return false;
        }
    }

    static RelativeLayout updateContentVideoView(Context context, Activity activity, View view, PostMessage postMessage) {
        return updateContentVideoView(context, ((RichInboxActivity)activity).getId(), view, postMessage);
    }

    static RelativeLayout updateContentVideoView(Context context, long activityId, View view, PostMessage postMessage) {
        if(activityId > 0 && postMessage.getContentVideo() != null && postMessage.getContentImage() == null) {
            final TextureView videoView = (TextureView) view.findViewById(context.getResources().getIdentifier("video", "id", context.getPackageName()));
            final ImageView videoOverlay = (ImageView) view.findViewById(context.getResources().getIdentifier("videoOverlay", "id", context.getPackageName()));
            final RelativeLayout videoLayout = (RelativeLayout) view.findViewById(context.getResources().getIdentifier("videoLayout", "id", context.getPackageName()));

            final String videoUrl = postMessage.getContentVideo();
            videoView.setVisibility(View.VISIBLE);
            videoLayout.setVisibility(View.VISIBLE);
            setVideoController(activityId, videoUrl, videoView, videoOverlay, context);
            return videoLayout;
        } else {
            return null;
        }
    }

    static boolean updateButtons(Context context, View view, PostMessage postMessage, RichContent originalMessage ) {
        Action[] actions = postMessage.getActions();
        if(actions != null && actions.length > 0) {
            LinearLayout buttonsLayout = (LinearLayout) view.findViewById(context.getResources().getIdentifier("buttons", "id", context.getPackageName()));
            Button[] buttons = new Button[]{
                    (Button) view.findViewById(context.getResources().getIdentifier("button1", "id", context.getPackageName())),
                    (Button) view.findViewById(context.getResources().getIdentifier("button2", "id", context.getPackageName())),
                    (Button) view.findViewById(context.getResources().getIdentifier("button3", "id", context.getPackageName()))
            };

            buttonsLayout.setVisibility(View.VISIBLE);
            for (int i = 0; i < buttons.length; ++i) {
                if (i < actions.length) {
                    PostMessageTemplate.setActionToButton(buttons[i], actions[i], originalMessage);
                } else {
                    buttons[i].setVisibility(View.GONE);
                }
            }
            return true;
        } else {
            return false;
        }
    }

    private static Action getAction(JSONObject actionJSON) {
        try {
            String type = actionJSON.getString("type");
            String name = actionJSON.optString("name", "");
            String value = actionJSON.get("value").toString();
            Map<String, String> payload = new HashMap<>();
            payload.put("value", value);
            Iterator<String> keys = actionJSON.keys();
            while(keys.hasNext()) {
                String key = keys.next();
                if(!"type".equals(key) && !"name".equals(key) && !"value".equals(key)) {
                    payload.put(key, actionJSON.get(key).toString());
                }
            }
            return new ActionImpl(type, name, payload);
        } catch(JSONException e) {
            return null;
        }
    }

    private static void setActionToButton(Button button, final Action action, final RichContent message) {
        button.setText(action.getName());
        button.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        button.setOnClickListener(v -> {
            Context context = v.getContext().getApplicationContext();
            MceNotificationAction actionImpl = MceNotificationActionRegistry.getNotificationAction(context, action.getType());
            if (actionImpl != null) {
                Map<String, String> payload = new HashMap<>();
                for (String key : action.getPayloadKeys()) {
                    payload.put(key, action.getPayloadValue(key));
                }
                actionImpl.handleAction(context, action.getType(), action.getType(), message.getAttribution(), null, payload, false);
                InboxEvents.sendInboxMessageActionTakenEvent(context, message, action);
            }
        });
    }

    static void setHidden(String videoUrl, long activityId) {
        synchronized (ACTIVITY_ID_TO_VIDEO_CACHE) {
            Map<String, VideoController> videoCache;
            videoCache = ACTIVITY_ID_TO_VIDEO_CACHE.get(activityId);
            if(videoCache != null) {
                VideoController controller = videoCache.get(videoUrl);
                if (controller != null) {
                    controller.pause();
                }
            }
        }
    }

    static class PostMessage {
        private final String header;
        private final String subHeader;
        private final String headerImage;
        private final String contentText;
        private final String contentImage;
        private final String contentVideo;
        private final Action[] actions;

        public PostMessage(RichContent richContent) throws JSONException {
            JSONObject content = richContent.getContent();
            if(content == null) {
                throw new JSONException("No content was found");
            }
            header = content.getString("header");
            subHeader = content.optString("subHeader", "");
            headerImage = content.optString("headerImage", null);
            contentText = content.optString("contentText", null);
            contentImage = content.optString("contentImage", null);
            contentVideo = content.optString("contentVideo", null);
            JSONArray actiobsJSONArray = content.optJSONArray("actions");
            if(actiobsJSONArray == null) {
                actions = null;
            } else {
                actions = new Action[actiobsJSONArray.length()];
                for(int i=0 ; i<actiobsJSONArray.length() ; ++i) {
                    actions[i] = getAction(actiobsJSONArray.getJSONObject(i));
                }
            }
        }

        public String getHeader() {
            return header;
        }

        public String getSubHeader() {
            return subHeader;
        }

        public String getHeaderImage() {
            return headerImage;
        }

        public String getContentText() {
            return contentText;
        }

        public String getContentImage() {
            return contentImage;
        }

        public String getContentVideo() {
            return contentVideo;
        }

        public Action[] getActions() {
            return actions;
        }
    }

    static class VideoController implements MediaPlayer.OnPreparedListener, MediaPlayer.OnCompletionListener,
            MediaPlayer.OnInfoListener, MediaPlayer.OnSeekCompleteListener, MediaPlayer.OnErrorListener,
            MediaPlayer.OnVideoSizeChangedListener, TextureView.SurfaceTextureListener, TextureView.OnClickListener,
            MediaController.MediaPlayerControl, MediaPlayer.OnBufferingUpdateListener {

        private final String videoUrl;
        private final MediaPlayer mediaPlayer;
        private TextureView videoView;
        private ImageView videoOverlay;
        private Context context;
        private boolean mediaPlayerPrepared;
        private boolean mediaPlayerPreparing;
        private boolean surfacePrepared;
        private boolean playing;
        private int bufferPercent;


        public VideoController(String videoUrl,  TextureView videoView, ImageView videoOverlay, Context context){
            Logger.d(TAG,"VIDEOLIFECYCLE - Video controller created: "+videoUrl);
            this.videoUrl = videoUrl;
            this.videoOverlay = videoOverlay;
            this.context = context;
            this.videoView = videoView;
            this.mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(videoUrl);
                mediaPlayer.setOnPreparedListener(this);
                mediaPlayer.setOnSeekCompleteListener(this);
                mediaPlayer.setOnCompletionListener(this);
                mediaPlayer.setOnVideoSizeChangedListener(this);
                mediaPlayer.setOnInfoListener(this);
                mediaPlayer.setOnBufferingUpdateListener(this);
            } catch (IOException ioe) {
                Logger.e(TAG, "Failed to load video " + videoUrl, ioe);
            }

            prepare();
        }

        public void updateVideoView(TextureView videoView, ImageView videoOverlay, Context context) {
            this.context = context;
            this.videoOverlay = videoOverlay;
            if(this.videoView != null && this.videoView != videoView) {
                this.videoView.setSurfaceTextureListener(null);
                this.videoView.setOnClickListener(null);
                this.videoView = videoView;
                surfacePrepared = false;
                prepare();
            } else {
                setReadyToPlay();
            }
        }

        @Override
        public void onCompletion(MediaPlayer mp) {
            try {
                Logger.d(TAG, "VIDEOLIFECYCLE - onCompletion: "+(mp != null ? mp.getCurrentPosition()+" , "+mp.getTrackInfo() : "NULL"));
                playing = false;
                videoOverlay.setImageResource(context.getResources().getIdentifier("ic_mce_video_wait", "drawable", context.getPackageName()));
                videoOverlay.setVisibility(View.VISIBLE);
                videoView.setOnClickListener(null);
                Logger.d(TAG, "Seeking on completion ");
                mediaPlayer.seekTo(0);
            } catch (Throwable t) {
                Logger.d(TAG, "seek on completion error",t);
            }
        }

        @Override
        public boolean onInfo(MediaPlayer mp, int what, int extra) {
            return false;
        }

        @Override
        public void onPrepared(MediaPlayer mp) {
            try {
                Logger.d(TAG, "VIDEOLIFECYCLE - onPrepared: " + (mp != null ? mp.getCurrentPosition() + " , " + mp.getTrackInfo() : "NULL"));
                mediaPlayerPrepared = true;
                mediaPlayerPreparing = false;
                setReadyToPlay();
            }    catch (Throwable t) {
                    Logger.d(TAG, "seek on prepared error",t);
                }
        }

        @Override
        public void onSeekComplete(MediaPlayer mp) {
            try {
                Logger.d(TAG, "VIDEOLIFECYCLE - onSeekComplete: " + (mp != null ? mp.getCurrentPosition() + " , " + mp.getTrackInfo() : "NULL"));
                if (!playing) {
                    setReadyToPlay();
                    videoView.setOnClickListener(this);
                }
            } catch (Throwable t) {
                Logger.d(TAG, "seek on seek complete error",t);
            }
        }

        @Override
        public void onVideoSizeChanged(MediaPlayer mp, int width, int height) {
        }

        @Override
        public boolean onError(MediaPlayer mp, int what, int extra) {
            Logger.e(TAG, "Video error for " + videoUrl + ": " + what + ", " + extra);
            return false;
        }

        @Override
        public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
            Logger.d(TAG, "VIDEOLIFECYCLE - onSurfaceTextureAvailable: "+width+", "+height);
            surfacePrepared = true;
            mediaPlayer.setSurface(new Surface(surface));
            if(!mediaPlayerPrepared && !mediaPlayerPreparing) {
                try {
                    mediaPlayerPreparing = true;
                    Logger.d(TAG, "VIDEOLIFECYCLE - onSurfaceTextureAvailable: prepareAsync");
                    mediaPlayer.prepareAsync();
                } catch (IllegalStateException ise) {
                    //prevent a crash if and when timing is wrong
                    Logger.e(TAG,"Error while preparing video", ise);
                }

            } else {
                Logger.d(TAG, "VIDEOLIFECYCLE - onSurfaceTextureAvailable: setReadyToPlay");
                setReadyToPlay();
            }
        }

        @Override
        public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {

        }

        @Override
        public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) {
            return false;
        }

        @Override
        public void onSurfaceTextureUpdated(SurfaceTexture surface) {

        }

        @Override
        public void onBufferingUpdate(MediaPlayer mp, int percent) {
            bufferPercent = percent;
        }

        @Override
        public void onClick(View v) {
            try {
                if (!mediaPlayerPrepared) {
                    return;
                }
                if (!playing) {
                    play();
                } else {
                    pause();
                }
            } catch (Throwable t) {
                Logger.d(TAG, "on click error",t);
            }
        }

        public void pause() {
            if (mediaPlayer.isPlaying()) {
                videoOverlay.setVisibility(View.VISIBLE);
                mediaPlayer.pause();
                playing = false;
                videoOverlay.setImageResource(context.getResources().getIdentifier("ic_mce_video_play", "drawable", context.getPackageName()));
            }
        }

        @Override
        public void start() {
            mediaPlayer.start();
        }

        @Override
        public int getDuration() {
            return mediaPlayer.getDuration();
        }

        @Override
        public int getCurrentPosition() {
            return mediaPlayer.getCurrentPosition();
        }

        @Override
        public void seekTo(int pos) {
            try {
                mediaPlayer.seekTo(pos);
            } catch (Throwable t) {
                Logger.d(TAG, "seek pos error",t);
            }
        }

        @Override
        public boolean isPlaying() {
            return mediaPlayer.isPlaying();
        }

        @Override
        public int getBufferPercentage() {
            return bufferPercent;
        }

        @Override
        public boolean canPause() {
            return mediaPlayer.isPlaying();
        }

        @Override
        public boolean canSeekBackward() {
            return true;
        }

        @Override
        public boolean canSeekForward() {
            return true;
        }

        @Override
        public int getAudioSessionId() {
            return mediaPlayer.getAudioSessionId();
        }

        public void play() {
            if(currentlyPlaying != null) {
                currentlyPlaying.pause();
            }
            videoOverlay.setVisibility(View.INVISIBLE);
            mediaPlayer.start();
            playing = true;
            currentlyPlaying = this;
        }

        public void prepare() {
            videoOverlay.setImageResource(context.getResources().getIdentifier("ic_mce_video_wait", "drawable", context.getPackageName()));
            this.videoView.setSurfaceTextureListener(this);
        }

        private void setReadyToPlay() {
            videoOverlay.setImageResource(context.getResources().getIdentifier("ic_mce_video_play", "drawable", context.getPackageName()));
            videoView.setOnClickListener(this);
        }
    }




}
