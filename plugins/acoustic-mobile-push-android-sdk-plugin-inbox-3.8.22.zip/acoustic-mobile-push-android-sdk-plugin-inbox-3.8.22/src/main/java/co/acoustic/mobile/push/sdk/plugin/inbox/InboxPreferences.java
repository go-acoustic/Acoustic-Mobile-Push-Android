/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.content.Context;

import co.acoustic.mobile.push.sdk.Preferences;
import co.acoustic.mobile.push.sdk.location.cognitive.DailyVisit;
import co.acoustic.mobile.push.sdk.util.Iso8601;
import co.acoustic.mobile.push.sdk.util.Logger;

import java.util.Date;

class InboxPreferences extends Preferences {

    public static final String TAG = "InboxPreferences";

    private static final String INBOX_STATUS_UPDATE_PAYLOAD = "inboxStatusUpdatePayload";


    public static String getInboxStatusUpdatePayload(Context context) {
        return getString(context, INBOX_STATUS_UPDATE_PAYLOAD, null);
    }

    public static void setInboxStatusUpdatePayload(Context context, String payload) {
        setString(context, INBOX_STATUS_UPDATE_PAYLOAD, payload);
        Logger.d(TAG,"Setting inbox status payload to "+payload);
    }
}
