/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.displayweb;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

/**
 * This is the display url activity. It contains a web view and 3 buttons: back, forward and done, which closes the activity.
 */
public class DisplayWebViewActivity extends AppCompatActivity {
   private WebView webView;
    private int actionBackId;
    private int actionForwardId;
    private int actionDoneId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        actionBackId = getResources().getIdentifier("action_back", "id", getPackageName());
        actionForwardId = getResources().getIdentifier("action_forward", "id", getPackageName());
        actionDoneId = getResources().getIdentifier("action_done", "id", getPackageName());

        super.onCreate(savedInstanceState);
        int layoutId = getResources().getIdentifier("action_webview_activity", "layout", getPackageName());
        setContentView(layoutId);
        String url = getIntent().getStringExtra("url");
        setTitle("");
        int webViewId = getResources().getIdentifier("webView", "id", getPackageName());
        webView = findViewById(webViewId);
        webView.setWebViewClient(new WebViewClient());
        if (url != null) {
            webView.loadUrl(url);
        }
    }

    /**
     * This method inflates the menu
     * @param menu The menu
     * @return boolean value
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        int menuId = getResources().getIdentifier("action_webview_menu", "menu", getPackageName());
        getMenuInflater().inflate(menuId, menu);
        return true;
    }

    /**
     * This method handles a menu selection (back, forward or done).
     * @param item The selected menu item (back, forward or done).
     * @return boolean value
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == actionBackId) {
            webView.goBack();
            return true;
        } else if (id == actionForwardId) {
            webView.goForward();
            return true;
        } else if (id == actionDoneId) {
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public static class PluginWebView extends WebView {

        public PluginWebView(Context context) {
            super(getContext(context));
        }

        public PluginWebView(Context context, AttributeSet attrs) {
            super(getContext(context), attrs);
        }

        public PluginWebView(Context context, AttributeSet attrs, int defStyleAttr) {
            super(getContext(context), attrs, defStyleAttr);
        }

        private static Context getContext(Context context) {
            return switch (Build.VERSION.SDK_INT) {
                case 21, 22 -> createNewContext(context);
                default -> context;
            };
        }

        private static Context createNewContext(Context context) {
            return context.createConfigurationContext(new Configuration());
        }
    }
}
