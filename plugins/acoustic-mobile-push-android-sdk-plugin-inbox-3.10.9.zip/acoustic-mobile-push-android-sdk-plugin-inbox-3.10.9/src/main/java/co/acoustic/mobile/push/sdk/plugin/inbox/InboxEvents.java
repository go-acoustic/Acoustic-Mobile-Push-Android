/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;


import android.content.Context;

import co.acoustic.mobile.push.sdk.api.Constants;
import co.acoustic.mobile.push.sdk.api.MceSdk;
import co.acoustic.mobile.push.sdk.api.OperationCallback;
import co.acoustic.mobile.push.sdk.api.OperationResult;
import co.acoustic.mobile.push.sdk.api.attribute.Attribute;
import co.acoustic.mobile.push.sdk.api.attribute.StringAttribute;
import co.acoustic.mobile.push.sdk.api.event.Event;
import co.acoustic.mobile.push.sdk.api.notification.Action;
import co.acoustic.mobile.push.sdk.notification.MceNotificationActionImpl;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class InboxEvents {

   public static void sendInboxNotificationOpenedEvent(final Context context, Action action, String attribution, String mailingId) {
        List<Attribute> eventAttributes = new LinkedList<Attribute>();
        eventAttributes.add(new StringAttribute("Extension", "inbox"));
        String contentId = action.getPayloadValue("value");
        if(contentId != null) {
            eventAttributes.add(new StringAttribute("richContentId", contentId));
        }
        final Event event = new Event(Constants.Notifications.SIMPLE_NOTIFICATION_EVENT_TYPE, "inboxMessageOpened", new Date(), eventAttributes, attribution, mailingId);
        MceSdk.getEventsClient(false).sendEvent(context, event, new OperationCallback<Event>() {
            @Override
            public void onSuccess(Event event, OperationResult result) {

            }

            @Override
            public void onFailure(Event event, OperationResult result) {
                MceSdk.getQueuedEventsClient().sendEvent(context, event);
            }
        });
    }

    public static void sendInboxMessageOpenedEvent(final Context context,RichContent message) {
        List<Attribute> eventAttributes = new LinkedList<Attribute>();
        eventAttributes.add(new StringAttribute("richContentId", message.getContentId()));
        eventAttributes.add(new StringAttribute("inboxMessageId", message.getMessageId()));

        final Event event = new Event("inbox", "messageOpened", new Date(), eventAttributes, message.getAttribution(), null);
        MceSdk.getEventsClient(false).sendEvent(context, event, new OperationCallback<Event>() {
            @Override
            public void onSuccess(Event event, OperationResult result) {

            }

            @Override
            public void onFailure(Event event, OperationResult result) {
                MceSdk.getQueuedEventsClient().sendEvent(context, event);
            }
        });
    }

    public static void sendInboxMessageActionTakenEvent(final Context context, RichContent message, Action action) {
        String name = action.getType();
        List<Attribute> eventAttributes = new LinkedList<Attribute>();
        MceNotificationActionImpl.ClickEventDetails clickEventDetails = MceNotificationActionImpl.getClickEventDetails(action.getType());
        if(clickEventDetails != null) {
            name = clickEventDetails.eventName;
            String value = action.getPayloadValue("value");
            eventAttributes.add(new StringAttribute(clickEventDetails.valueName, value));
        } else {
            for(String key : action.getPayloadKeys()) {
                eventAttributes.add(new StringAttribute(key, action.getPayloadValue(key)));
            }
        }

        eventAttributes.add(new StringAttribute("richContentId", message.getContentId()));
        eventAttributes.add(new StringAttribute("inboxMessageId", message.getMessageId()));
        final Event event = new Event("inboxMessage", name, new Date(), eventAttributes, message.getAttribution(), null);
        MceSdk.getEventsClient(false).sendEvent(context, event , new OperationCallback<Event>() {
            @Override
            public void onSuccess(Event event, OperationResult result) {

            }

            @Override
            public void onFailure(Event event, OperationResult result) {
                MceSdk.getQueuedEventsClient().sendEvent(context, event);
            }
        });
    }
}
