/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;


import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Point;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import co.acoustic.mobile.push.sdk.util.Logger;

import org.json.JSONException;

/**
 * This class is the preview implementation of the post template
 */
public class PostMessagePreviewFragment implements InboxMessagePreviewFragment {

   private static final String TAG = "PostMessagePreviewFragment";


    /**
     * This method generates a new preview view
     * @param adapter The messages adapter
     * @param context The application context
     * @param cursor The messages cursor
     * @param parent The fragment parent
     * @return The new view
     */
    @Override
    public View newView(final CursorAdapter adapter, final Context context, Cursor cursor, ViewGroup parent) {

        RichInboxListFragment.MessageCursorAdapter messageCursorAdapter = (RichInboxListFragment.MessageCursorAdapter)adapter;
        RichContent message = messageCursorAdapter.getMessageCursor().getRichContent();
        try {
            PostMessageTemplate.PostMessage postMessage = new PostMessageTemplate.PostMessage(message);
            String layoutName = "post_inbox_layout";
            if(postMessage.getContentText() != null && postMessage.getContentImage() != null) {
                layoutName = "post_inbox_text_image_layout";
            } else if(postMessage.getContentText() != null && postMessage.getContentVideo() != null) {
                layoutName = "post_inbox_text_video_layout";
            }
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View rowView = inflater.inflate(context.getResources().getIdentifier(layoutName, "layout", context.getPackageName()), parent, false);

            int height = getSizeInDp(40, rowView);

            PostMessageTemplate.updateHeaderView(context, (Activity) messageCursorAdapter.getContext(), rowView, postMessage);
            PostMessageTemplate.updateHeaderViewState(context, (Activity)messageCursorAdapter.getContext(), rowView, message.getIsRead(), !InboxPlugin.shouldDisplayInboxMessage(message));


            TextView textView = PostMessageTemplate.updateContentTextView(context, rowView, postMessage);
            if(textView != null) {
                height += getRequiredTextViewHeight(textView, (Activity) messageCursorAdapter.getContext());
            }

            if(PostMessageTemplate.updateContentImageView(context, (Activity) messageCursorAdapter.getContext(), rowView, postMessage)) {
                height += getSizeInDp(100, rowView);
            } else {
                RelativeLayout videoLayout = PostMessageTemplate.updateContentVideoView(context, (Activity) messageCursorAdapter.getContext(), rowView, postMessage);
                if (videoLayout != null) {
                    videoLayout.setMinimumHeight(getSizeInDp(150, rowView));
                    videoLayout.setMinimumWidth(getScreenSize((Activity) messageCursorAdapter.getContext()).x);
                    height += getSizeInDp(150, rowView);
                }
            }



            if(PostMessageTemplate.updateButtons(context, rowView, postMessage, message)) {
                height += getSizeInDp(40, rowView);
            }

            rowView.setMinimumHeight(height);
            rowView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height));

            return rowView;
        } catch(JSONException e) {
            Logger.e(TAG, "Failed to update inbox row view", e);
            return null;
        }

    }


    /**
     * This method display an html message preview in the fragment
     * @param adapter The messages adapter
     * @param view The containg view
     * @param context The application context
     * @param cursor The messages cursor
     */
    @Override
    public void bindView(CursorAdapter adapter, View view, Context context, Cursor cursor) {


    }

    /**
     * This method is called when the view is hiiden
     * @param message The view message
     * @param activityId The containing activity id
     */
    @Override
    public void viewHidden(RichContent message, long activityId) {
        if(message.getTemplate().equals("post")) {
            try {
                PostMessageTemplate.PostMessage postMessage = new PostMessageTemplate.PostMessage(message);
                if(postMessage.getContentVideo() != null) {
                    PostMessageTemplate.setHidden(postMessage.getContentVideo(), activityId);
                }
            } catch (Exception e) {

            }
        }
    }

    private int getSizeInDp(int size, View view) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, size, view.getContext().getResources().getDisplayMetrics());
    }

    private int getRequiredTextViewHeight(TextView textView, Activity activity) {
        Point p = getScreenSize(activity);
        int widthMeasureSpec = View.MeasureSpec.makeMeasureSpec(p.x, View.MeasureSpec.AT_MOST);
        int heightMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        textView.measure(widthMeasureSpec, heightMeasureSpec);
        return textView.getMeasuredHeight();
    }

    private Point getScreenSize(Activity activity) {
        Point p = new Point();
        activity.getWindowManager().getDefaultDisplay().getSize(p);
        return p;
    }


}
