/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

/**
 * This class is the preview implementation of the html template
 */
public class HtmlInboxMessagePreviewFragment implements InboxMessagePreviewFragment {

   /**
     * This method generates a new preview view
     * @param adapter The messages adapter
     * @param context The application context
     * @param cursor The messages cursor
     * @param parent The fragment parent
     * @return The new view
     */
    @Override
    public View newView(CursorAdapter adapter, Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(context.getResources().getIdentifier("list_item_rich_inbox", "layout", context.getPackageName()), parent, false);

        ViewHolder holder = new ViewHolder();
        holder.setChevronView((ImageView) rowView.findViewById(context.getResources().getIdentifier("chevron", "id", context.getPackageName())));
        holder.setSubjectView((TextView) rowView.findViewById(context.getResources().getIdentifier("subject", "id", context.getPackageName())));
        holder.setPreviewView((TextView) rowView.findViewById(context.getResources().getIdentifier("preview", "id", context.getPackageName())));
        holder.setDateView((TextView) rowView.findViewById(context.getResources().getIdentifier("date", "id", context.getPackageName())));
        rowView.setTag(holder);

        return rowView;
    }

    /**
     * This method display an html message preview in the fragment
     * @param adapter The messages adapter
     * @param view The containing view
     * @param context The application context
     * @param cursor The messages cursor
     */
    @Override
    public void bindView(CursorAdapter adapter, View view, Context context, Cursor cursor) {
        RichInboxListFragment.MessageCursorAdapter messageCursorAdapter = (RichInboxListFragment.MessageCursorAdapter)adapter;
        ViewHolder holder = (ViewHolder) view.getTag();

        RichContent message = holder.getMessage();
        if(message==null)
        {
            message = messageCursorAdapter.getMessageCursor().getRichContent();
            holder.setMessage(message);
        }

        // Read/unread status



        Typeface typeface = Typeface.defaultFromStyle(Typeface.BOLD);
        TypedArray textColor = context.getTheme().obtainStyledAttributes(new int[] {android.R.attr.textColor});
        int color = textColor.getColor(0, 0);
        if(message.getIsRead()) {
            typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
        }
        if(!InboxPlugin.shouldDisplayInboxMessage(message)) {
            typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
            textColor = context.getTheme().obtainStyledAttributes(new int[] {android.R.attr.textColorPrimaryDisableOnly});
            color = textColor.getColor(0, 0);
        }

        TextView dateView = holder.getDateView();
        Date send = message.getSendDate();       
        SimpleDateFormat format = new SimpleDateFormat("M/d/yy");
        CharSequence dateString = format.format(send);
        dateView.setText(dateString);
        dateView.setTypeface(typeface);
        dateView.setTextColor(color);

        if(messageCursorAdapter.isTablet()) {
            // tablet interface

            // Selected message status blue color
            int currentIndex = messageCursorAdapter.getRichInboxFragment().getCurrentIndex();

            ImageView chevronView = holder.getChevronView();
            if (currentIndex != -1 && cursor.getPosition() == currentIndex) {
                chevronView.setImageResource(context.getResources().getIdentifier("highlight_chevron", "drawable", context.getPackageName()));
                //color = Color.argb(255, 165, 220, 255);
            } else {
                chevronView.setImageResource(context.getResources().getIdentifier("chevron", "drawable", context.getPackageName()));
            }
        }

        TextView subjectView = holder.getSubjectView();
        subjectView.setText(message.getSubject());
        subjectView.setTypeface(typeface);
        subjectView.setTextColor(color);
        TextView previewView = holder.getPreviewView();
        previewView.setText(message.getPreview());
        previewView.setTypeface(typeface);
        previewView.setTextColor(color);
    }

    /**
     * This method is called when the view is hiiden
     * @param message The view message
     * @param activityId The containing activity id
     */
    @Override
    public void viewHidden(RichContent message, long activityId) {

    }

    private class ViewHolder
    {
        TextView dateView;
        TextView previewView;
        TextView subjectView;
        ImageView chevronView;

        public RichContent getMessage() {
            return message;
        }

        public void setMessage(RichContent message) {
            this.message = message;
        }

        RichContent message;

        public TextView getDateView() {
            return dateView;
        }

        public void setDateView(TextView dateView) {
            this.dateView = dateView;
        }

        public TextView getPreviewView() {
            return previewView;
        }

        public void setPreviewView(TextView previewView) {
            this.previewView = previewView;
        }

        public TextView getSubjectView() {
            return subjectView;
        }

        public void setSubjectView(TextView subjectView) {
            this.subjectView = subjectView;
        }

        public ImageView getChevronView() {
            return chevronView;
        }

        public void setChevronView(ImageView chevronView) {
            this.chevronView = chevronView;
        }
    }

}
