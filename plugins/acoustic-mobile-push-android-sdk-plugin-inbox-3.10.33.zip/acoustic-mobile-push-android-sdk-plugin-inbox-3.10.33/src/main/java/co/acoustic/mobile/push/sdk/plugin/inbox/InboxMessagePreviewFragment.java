/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.content.Context;
import android.database.Cursor;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;

/**
 * This is the interface for the inbox template preview display
 */
public interface InboxMessagePreviewFragment {

   /**
     * This method generates a new preview view
     * @param adapter The messages adapter
     * @param context The application context
     * @param cursor The messages cursor
     * @param parent The fragment parent
     * @return The new view
     */
   View newView(CursorAdapter adapter, Context context, Cursor cursor, ViewGroup parent);

    /**
     * This method display an html message preview in the fragment
     * @param adapter The messages adapter
     * @param view The containing view
     * @param context The application context
     * @param cursor The messages cursor
     */
    void bindView(CursorAdapter adapter, View view, Context context, Cursor cursor);

    /**
     * This mrthod is called when the view is hiiden
     * @param message The view message
     * @param activityId The containing activity id
     */
    void viewHidden(RichContent message, long activityId);
}
