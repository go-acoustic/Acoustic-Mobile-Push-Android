/*
 * Copyright (C) 2025 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import co.acoustic.mobile.push.sdk.api.notification.Action;
import co.acoustic.mobile.push.sdk.notification.ActionImpl;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


/**
 * This class is the inbox message object
 */
public class RichContent {
   private String contentId;
    private String messageId;
    private String template;
    private JSONObject content;
    private String attribution;
    private Date sendDate;
    private Date expirationDate;
    private Boolean isDeleted;
    private Boolean isRead;
    private String pushMailingId;

    /**
     * Retrieves the message content id
     * @return The message content id
     */
    public String getContentId() {
        return contentId;
    }

    /**
     * Retrieves the message id
     * @return The message id
     */
    public String getMessageId() {
        return messageId;
    }

    /**
     * Sets the message content id
     * @param contentId The message content id
     */
    public void setContentId(String contentId) {
        this.contentId = contentId;
    }

    /**
     * Sets the message id
     * @param messageId The message id
     */
    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    /**
     * Retrieves the message template
     * @return The template name
     */
    public String getTemplate() {
        return template;
    }

    /**
     * Retrieves the JSON content
     * @return The JSON content
     */
    public JSONObject getContent() {
        return content;
    }

    /**
     * Sets the JSON content
     * @param content The JSON content
     */
    public void setContent(JSONObject content) {
        this.content = content;
    }

    /**
     * Retrieves the message send date
     * @return The send date
     */
    public Date getSendDate() {
        return sendDate;
    }

    /**
     * Sets the message send date
     * @param sendDate The send date
     */
    public void setSendDate(Date sendDate) {
        this.sendDate = sendDate;
    }

    /**
     * Retrieves the message expiration date
     * @return The expiration date
     */
    public Date getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the message expiration date
     * @param expirationDate The expiration date
     */
    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    /**
     * Checks if message is deleted
     * @return true if deleted, false otherwise
     */
    public Boolean getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets message as deleted
     * @param isDeleted true for deleted, false otherwise
     */
    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    /**
     * Check if message is read
     * @return true for read, false otherwise
     */
    public Boolean getIsRead() {
        return isRead;
    }

    /**
     * Set message read state
     * @param isRead true for read, false otherwise
     */
    public void setIsRead(Boolean isRead) {
        this.isRead = isRead;
    }

    /**
     * Sets the message template
     * @param template The template name
     */
    public void setTemplate(String template) {
        this.template = template;
    }

    /**
     * Retrieves the pushMailingId
     * @return The pushMailingId
     */
    public String getPushMailingId() {
        return pushMailingId;
    }

    /**
     * Sets the pushMailingId
     * @param pushMailingId The pushMailingId
     */
    public void setPushMailingId(String pushMailingId) {
        this.pushMailingId = pushMailingId;
    }

    /**
     * Retrieves a map from action id to action as a JSON object
     * @return The JSON object map
     * @throws JSONException If any JSON error occurs
     */
    public JSONObject getIdToAction() throws JSONException {
        JSONObject messageDetailsJSON = content.optJSONObject("messageDetails");
        if(messageDetailsJSON != null) {
            Object actionsObj = messageDetailsJSON.opt("actions");
            if(actionsObj == null) {
                actionsObj = content.opt("actions");
            }
            if(actionsObj != null) {
                if(actionsObj instanceof JSONArray) {
                    JSONArray actionsArray = messageDetailsJSON.optJSONArray("actions");
                    JSONObject idToAction = new JSONObject();
                    for(int i=0;i<actionsArray.length();++i) {
                        String id =  actionsArray.getJSONObject(i).optString("id");
                        if(id != null) {
                            idToAction.put(id, actionsArray.getJSONObject(i));
                        }
                    }
                    return idToAction;
                } else if(actionsObj instanceof JSONObject) {
                    return (JSONObject)actionsObj;
                } else {
                    return new JSONObject();
                }
            }
        }
        return new JSONObject();
    }

    /**
     * Retrieves the message attribution
     * @return The attribution
     */
    public String getAttribution() {
        return attribution;
    }

    /**
     * Sets the message attribution
     * @param attribution The attribution
     */
    public void setAttribution(String attribution) {
        this.attribution = attribution;
    }

    /**
     * Retrieves the message subject
     * @return The subject
     */
    public String getSubject() {
        JSONObject messagePreviewJSON = content.optJSONObject("messagePreview");
        if(messagePreviewJSON != null) {
            return messagePreviewJSON.optString("subject", "no subject");
        } else {
            return "no subject";
        }
    }

    /**
     * Retrieves the message priview text
     * @return The preview trxt
     */
    public String getPreview() {
        JSONObject messagePreviewJSON = content.optJSONObject("messagePreview");
        if(messagePreviewJSON != null) {
            return messagePreviewJSON.optString("previewContent", "no preview");
        } else {
            return "no preview";
        }
    }

    /**
     * Retrieves the message rich content
     * @return The rich content
     */
    public String getRichContent() {
        JSONObject messagePreviewJSON = content.optJSONObject("messageDetails");
        if(messagePreviewJSON != null) {
            return messagePreviewJSON.optString("richContent", "no rich content");
        } else {
            return "no rich content";
        }
    }

    /**
     * Chhecks if the message is expired
     * @return true if expired, false otherwise
     */
    public boolean getIsExpired() {
        return expirationDate.before( new Date() );
    }

    /**
     * Retrieves message action by id
     * @param id The action id
     * @return The action
     */
    public Action getAction(String id) {
        try {
            JSONObject actionJSON = getIdToAction().optJSONObject(id);
            if(actionJSON != null) {
                String type = actionJSON.getString("type");
                String name = actionJSON.optString("name", "");
                String value = actionJSON.get("value").toString();
                Map<String, String> payload = new HashMap<String, String>();
                payload.put("value", value);
                Iterator<String> keys = actionJSON.keys();
                while(keys.hasNext()) {
                    String key = keys.next();
                    if(!"type".equals(key) && !"name".equals(key) && !"value".equals(key)) {
                        payload.put(key, actionJSON.get(key).toString());
                    }
                }
                Action action = new ActionImpl(type, name, payload);
                return action;
            } else {
                return null;
            }
        } catch(JSONException e) {
            return null;
        }
    }

    /**
     * Translates the message to JSON object
     * @param content The message
     * @return The message as a JSON object
     * @throws JSONException If any JSON error occurs
     */
    public static JSONObject toJSON(RichContent content) throws JSONException {
        JSONObject contentJSON = new JSONObject();
        contentJSON.put("contentId", content.getContentId());
        contentJSON.put("mailingId", content.getMessageId());
        contentJSON.put("attribution", content.getAttribution());
        contentJSON.put("template", content.getTemplate());
        contentJSON.put("content", content.getContent());
        contentJSON.put("expirationDate", content.getExpirationDate().getTime());
        contentJSON.put("sendDate", content.getSendDate().getTime());
        contentJSON.put("isRead", content.isRead);
        contentJSON.put("isDeleted", content.isDeleted);
        return contentJSON;
    }

    /**
     * Builds the message from a JSON object
     * @param contentJSON The JSON object
     * @return The message
     * @throws JSONException If any JSON error occurs
     */
    public static RichContent fromJSON(JSONObject contentJSON) throws JSONException {
        RichContent content = new RichContent();
        content.setContentId(contentJSON.getString("contentId"));
        content.setMessageId(contentJSON.optString("mailingId"));
        content.setAttribution(contentJSON.optString("attribution"));
        content.setTemplate(contentJSON.getString("template"));
        content.setContent(contentJSON.getJSONObject("content"));
        content.setExpirationDate(new Date(contentJSON.getLong("expirationDate")));
        content.setSendDate(new Date(contentJSON.getLong("sendDate")));
        content.setIsRead(contentJSON.getBoolean("isRead"));
        content.setIsDeleted(contentJSON.getBoolean("isDeleted"));
        return content;
    }
}
