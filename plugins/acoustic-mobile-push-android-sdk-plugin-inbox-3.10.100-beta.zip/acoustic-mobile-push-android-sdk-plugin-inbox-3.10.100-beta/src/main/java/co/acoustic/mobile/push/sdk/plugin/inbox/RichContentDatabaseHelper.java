/*
 * Copyright (C) 2025 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.CharArrayBuffer;
import android.database.ContentObserver;
import android.database.Cursor;
import android.database.DataSetObserver;
import android.net.Uri;
import android.os.Bundle;

import co.acoustic.mobile.push.sdk.api.Constants;
import co.acoustic.mobile.push.sdk.api.db.SdkDatabase;
import co.acoustic.mobile.push.sdk.api.db.SdkDatabaseCursor;
import co.acoustic.mobile.push.sdk.api.db.SdkDatabaseOpenHelper;
import co.acoustic.mobile.push.sdk.db.DbAdapter;
import co.acoustic.mobile.push.sdk.util.Logger;
import co.acoustic.mobile.push.sdk.messaging.MessagingManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * This class is the inbox messages dao.
 */
public class RichContentDatabaseHelper {
    private static final String TAG = "RichContentDatabaseHelper";

    private static final String DB_NAME = "messages.sqlite";
    private static final int VERSION = 5;
    private static final String TABLE_NAME = "notifications";
    // This is original use
    private static final String COLUMN_MESSAGE_ID = "mailingId";
    // This is the actual push mailing id
    private static final String COLUMN_PUSH_MAILING_ID = "pushMailingId";
    private static final String COLUMN_CONTENT_ID = "contentId";
    private static final String COLUMN_TEMPLATE = "template";
    private static final String COLUMN_CONTENT = "content";
    private static final String COLUMN_ATTRIBUTION = "attribution";
    private static final String COLUMN_SEND_DATE = "sendDate";
    private static final String COLUMN_EXPIRATION_DATE = "expirationDate";
    private static final String COLUMN_IS_DELETED = "isDeleted";
    private static final String COLUMN_IS_READ = "isRead";

    private final Context context;
    private static RichContentDatabaseHelper richContentDatabaseHelper;

    private static final String DB_ADD_COLUMN_PUSH_MAILING_ID = "ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COLUMN_PUSH_MAILING_ID + " Text;";
    private Boolean hasPushMailingId;

    /**
     * Gets the dao instance
     *
     * @param context The application's context
     * @return The dao instance
     */
    public static RichContentDatabaseHelper getRichContentDatabaseHelper(Context context) {
        Logger.d(TAG, "Calling getter on Rich " + TAG);

        if (richContentDatabaseHelper == null)
            Logger.d(TAG, "Static singletong is null, calling constructor new RichContentDatabaseHelper(context)");
        if (context != null) {
            Logger.d(TAG, "Context is not null");
        } else {
            Logger.e(TAG, "Context is null. Can't call constructor");
        }

        richContentDatabaseHelper = new RichContentDatabaseHelper(context);
        return richContentDatabaseHelper;
    }

    protected final SdkDatabaseOpenHelper databaseHelper;

    /**
     * Creates a new rich context database helper
     *
     * @param context The application's context
     */
    public RichContentDatabaseHelper(Context context) {
        hasPushMailingId = false;
        this.context = context;
        databaseHelper = DbAdapter.getDatabaseImpl(context).createOpenHelper(context, DB_NAME, VERSION, new SdkDatabaseOpenHelper.LifeCycleListener() {
            @Override
            public void onCreate(SdkDatabase database) {
                // create notifications table
                String createTableSql = "CREATE TABLE IF NOT EXISTS \"notifications\"(" + "" +
                        "\"_id\" Numeric PRIMARY KEY, " +
                        "\"" + COLUMN_CONTENT + "\" Text, " +
                        "\"" + COLUMN_CONTENT_ID + "\" Text, " +
                        "\"" + COLUMN_MESSAGE_ID + "\" Text, " +
                        "\"" + COLUMN_TEMPLATE + "\" Text, " +
                        "\"" + COLUMN_ATTRIBUTION + "\" Text, " +
                        "\"" + COLUMN_EXPIRATION_DATE + "\" INTEGER, " +
                        "\"" + COLUMN_IS_DELETED + "\" Text, " +
                        "\"" + COLUMN_IS_READ + "\" Text, " +
                        "\"" + COLUMN_SEND_DATE + "\" INTEGER, " +
                        "\"" + COLUMN_PUSH_MAILING_ID + "\" Text);";
                Logger.d(TAG, createTableSql);
                database.execSQL(createTableSql);

                String contentIndexTableSql = "CREATE INDEX \"contentIdIndex\" ON \"notifications\"( \"contentId\" );";
                Logger.d(TAG, contentIndexTableSql);
                database.execSQL(contentIndexTableSql);

                String messageIndexTableSql = "CREATE UNIQUE INDEX \"messageIdIndex\" ON \"notifications\"( \"mailingId\", \"pushMailingId\"  );";
                Logger.d(TAG, messageIndexTableSql);
                database.execSQL(messageIndexTableSql);
            }

            @Override
            public void onUpgrade(SdkDatabase database, int oldVersion, int newVersion) {
                Logger.d(TAG, "On Upgrade was called");
                if(oldVersion <= 5) {
                    Logger.d(TAG, "Updating inbox table from " + oldVersion + " to " + newVersion);
                    updateHelper(database);
                }
            }

            /**
             * Used to help update to new table format and columns.
             * @param db SdkDatabase.
             */
            private void updateHelper(SdkDatabase db) {
                String DB_DROP_TABLE = "DROP TABLE \"" + TABLE_NAME + "\";";

                db.beginTransaction();
                List<RichContent> allMessages2 = new LinkedList<>();
                MessageCursor cursor = getAllMessages(db);
                while (cursor.moveToNext()) {
                    RichContent rc = cursor.getRichContent();
                    allMessages2.add(rc);
                }
                Logger.d(TAG, DB_DROP_TABLE);
                db.execSQL(DB_DROP_TABLE);
                onCreate(db);
                for (RichContent message : allMessages2) {
                    insertMessage(message, db);
                }
                db.setTransactionSuccessful();
                db.endTransaction();
            }

            @Override
            public void onDowngrade(SdkDatabase database, int oldVersion, int newVersion) {

            }

            @Override
            public void onConfigure(SdkDatabase database) {

            }
        });
    }

    /**
     * Deletes an inbox message
     *
     * @param message The message
     */
    public void deleteMessage(RichContent message) {
        deleteMessageById(message.getMessageId());
    }

    /**
     * Deletes an inbox message
     *
     * @param messageId The message id
     * @return the number of messages deleted
     */
    public long deleteMessageById(String messageId) {
        String[] whereArgs = {messageId};
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_DELETED, true);
        long id = databaseHelper.getWritableDatabase().update(TABLE_NAME, cv, COLUMN_MESSAGE_ID + "=?", whereArgs);
        MessagingManager.broadcastFeedback(context, Constants.Feedback.BroadcastAction.INBOX_COUNT_UPDATE, null, null);
        return id;
    }

    /**
     * Adds a new inbox message
     *
     * @param message The message
     */
    public void insertMessage(RichContent message) {
        SdkDatabase db = databaseHelper.getWritableDatabase();
        // Try to get value or insert a null/empty string
        if (!existsColumnInTable(db,  COLUMN_PUSH_MAILING_ID)) {
            if (!hasPushMailingId) {
                hasPushMailingId = true;
            }
            // Fix missing column
            db.execSQL(DB_ADD_COLUMN_PUSH_MAILING_ID);
        }
        insertMessage(message, db);
    }

    private boolean existsColumnInTable(SdkDatabase inDatabase, String columnToCheck) {
        Boolean result = false;
        Cursor mCursor = null;
        String sqlQuery = null;
        try {
            sqlQuery = "SELECT * FROM " + TABLE_NAME + " LIMIT 0";
            // Query 1 row
            mCursor = inDatabase.rawQuery(sqlQuery, null);

            // getColumnIndex() gives us the index (0 to ...) of the column - otherwise we get a -1
            if (mCursor.getColumnIndex(columnToCheck) != -1) {
                result = true;
            }
        } catch (Exception Exp) {
            Logger.e(TAG, "When checking whether a column exists in the table, an error occurred: " + sqlQuery + " : Exception: " + Exp.toString());
            return false;
        } finally {
            if (mCursor != null) mCursor.close();
        }
        return result;
    }

    boolean insertMessage(RichContent message, SdkDatabase db) {
        try {
            message = InboxPlugin.getInboxControl().processMessageBeforeDbStorage(message);
        } catch (Throwable t) {
            Logger.e(TAG, "process message failed " + message, t);
        }
        if (message != null) {
            ContentValues cv = new ContentValues();
            cv.put(COLUMN_MESSAGE_ID, message.getMessageId());
            cv.put(COLUMN_CONTENT_ID, message.getContentId());
            cv.put(COLUMN_TEMPLATE, message.getTemplate());
            cv.put(COLUMN_CONTENT, message.getContent().toString());
            cv.put(COLUMN_ATTRIBUTION, message.getAttribution());
            cv.put(COLUMN_SEND_DATE, message.getSendDate().getTime());
            cv.put(COLUMN_EXPIRATION_DATE, message.getExpirationDate().getTime());
            cv.put(COLUMN_IS_DELETED, message.getIsDeleted());
            cv.put(COLUMN_IS_READ, message.getIsRead());
            cv.put(COLUMN_PUSH_MAILING_ID, message.getPushMailingId());
            boolean added = (db.insert(TABLE_NAME, null, cv) != -1);
            if (added) {
                try {
                    InboxPlugin.getInboxControl().messageAddedToDbStorage(message);
                } catch (Throwable t) {
                    Logger.e(TAG, "message add prompt failed " + message, t);
                }
            }
            return added;
        } else {
            return true;
        }
    }

    /**
     * Gets all non deleted messages
     *
     * @return A cursor for all messages
     */
    public MessageCursor getMessages() {
        return getMessages(COLUMN_IS_DELETED, "0");
    }

    /**
     * Gets a message by content id
     *
     * @param contentId The content id
     * @return A cursor containing the message
     */
    public MessageCursor getMessagesByContentId(String contentId) {
        return getMessages(COLUMN_CONTENT_ID, contentId);
    }

    /**
     * Gets a message by message id
     *
     * @param messageId The message id
     * @return A cursor containing the message
     */
    public MessageCursor getMessagesByMessageId(String messageId) {
        return getMessages(COLUMN_MESSAGE_ID, messageId);
    }

    /**
     * Retrieves messages where column 'field' equals 'value'
     *
     * @param field The column name
     * @param value The column value
     * @return The application's context
     */
    public MessageCursor getMessages(String field, String value) {
        String[] args = {value};
        SdkDatabaseCursor wrapped = databaseHelper.getReadableDatabase().query(TABLE_NAME, null, field + "=?", args, null, null,
                COLUMN_SEND_DATE + getMessagesOrder());
        return new MessageCursor(wrapped);
    }

    /**
     * Retrieves all messages
     *
     * @return The application's context
     */
    MessageCursor getAllMessages(SdkDatabase db) {
        SdkDatabaseCursor wrapped = db.query(TABLE_NAME, null, null, null, null, null,
                COLUMN_SEND_DATE + getMessagesOrder());
        return new MessageCursor(wrapped);
    }

    /**
     * Set message as read
     *
     * @param message The message
     */
    public void setMessageRead(RichContent message) {
        setMessageReadById(message.getMessageId());
    }

    /**
     * Set message as read
     *
     * @param messageId The message id
     * @return The number of messages updated
     */
    public int setMessageReadById(String messageId) {
        String[] args = {messageId};
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_READ, true);
        int code = databaseHelper.getWritableDatabase().update(TABLE_NAME, cv, COLUMN_MESSAGE_ID + "=?", args);
        MessagingManager.broadcastFeedback(context, Constants.Feedback.BroadcastAction.INBOX_COUNT_UPDATE, null, null);
        return code;
    }

    /**
     * Set message as unread
     *
     * @param message The message
     */
    public void setMessageUnread(RichContent message) {
        setMessageUnreadById(message.getMessageId());
    }

    /**
     * Set message as unread
     *
     * @param messageId The message id
     * @return The number of messages updated
     */
    public int setMessageUnreadById(String messageId) {
        String[] args = {messageId};
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_READ, false);
        int code = databaseHelper.getWritableDatabase().update(TABLE_NAME, cv, COLUMN_MESSAGE_ID + "=?", args);
        MessagingManager.broadcastFeedback(context, Constants.Feedback.BroadcastAction.INBOX_COUNT_UPDATE, null, null);
        return code;
    }

    /**
     * Deletes all message marked as deleted
     */
    public void clearDeletedMessages() {
        String[] whereArgs = {"0"};
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_IS_DELETED, true);
        int deleted = databaseHelper.getWritableDatabase().delete(TABLE_NAME, COLUMN_IS_DELETED + "!=?", whereArgs);
    }

    private String getMessagesOrder() {
        InboxPlugin.InboxControl inboxControl = InboxPlugin.getInboxControl();
        boolean isAscending = true;
        try {
            isAscending = inboxControl.isMessagesSortAscending();
        } catch (Throwable t) {
            Logger.e(TAG, "Order control failed", t);
        }
        return (isAscending ? " asc" : " desc");
    }

    public void clearAllMessages() {
        databaseHelper.getWritableDatabase().delete(TABLE_NAME, null, null);
        MessagingManager.broadcastFeedback(context, Constants.Feedback.BroadcastAction.INBOX_COUNT_UPDATE, null, null);
    }

    /**
     * This class is a cursor for inbox messages
     */
    public class MessageCursor implements SdkDatabaseCursor {

        private final List<String> types = new ArrayList<>();
        private final SdkDatabaseCursor cursor;

        MessageCursor(SdkDatabaseCursor cursor) {
            this.cursor = cursor;
        }

        /**
         * Retrieves the new inbox message
         *
         * @return The message
         */
        public RichContent getRichContent() {

            RichContent message = new RichContent();

            int messageIdColumnIndex = getColumnIndex(COLUMN_MESSAGE_ID);
            if (messageIdColumnIndex < 0) {
                messageIdColumnIndex = getColumnIndex("messageId");
            }
            String messageId = getString(messageIdColumnIndex);
            message.setMessageId(messageId);

            String pushMailingId = getColumnIndex(COLUMN_PUSH_MAILING_ID) == -1 ? "" : getString(getColumnIndex(COLUMN_PUSH_MAILING_ID));
            message.setPushMailingId(pushMailingId);

            String contentId = getString(getColumnIndex(COLUMN_CONTENT_ID));
            message.setContentId(contentId);

            String template = getString(getColumnIndex(COLUMN_TEMPLATE));
            message.setTemplate(template);

            String attribution = getString(getColumnIndex(COLUMN_ATTRIBUTION));
            message.setAttribution(attribution);

            String contentString = getString(getColumnIndex(COLUMN_CONTENT));
            JSONObject content;
            try {
                content = new JSONObject(contentString);
            } catch (JSONException e) {
                Logger.e(TAG, "Failed to get rich content", e);
                return null;
            }
            message.setContent(content);

            Long sendDateLong = getLong(getColumnIndex(COLUMN_SEND_DATE));
            Date sendDate = new Date(sendDateLong);
            message.setSendDate(sendDate);


            Long expirationDateLong = getLong(getColumnIndex(COLUMN_EXPIRATION_DATE));
            Date expirationDate = new Date(expirationDateLong);
            message.setExpirationDate(expirationDate);

            Boolean isDeleted = getInt(getColumnIndex(COLUMN_IS_DELETED)) > 0;
            message.setIsDeleted(isDeleted);

            Boolean isRead = getInt(getColumnIndex(COLUMN_IS_READ)) > 0;
            message.setIsRead(isRead);

            return message;
        }

        @Override
        public int getCount() {
            return cursor.getCount();
        }

        @Override
        public int getPosition() {
            return cursor.getPosition();
        }

        @Override
        public boolean move(int offset) {
            return cursor.move(offset);
        }

        @Override
        public boolean moveToPosition(int position) {
            return cursor.moveToPosition(position);
        }

        @Override
        public boolean moveToFirst() {
            return cursor.moveToFirst();
        }

        @Override
        public boolean moveToLast() {
            return cursor.moveToLast();
        }

        @Override
        public boolean moveToNext() {
            return cursor.moveToNext();
        }

        @Override
        public boolean moveToPrevious() {
            return cursor.moveToPrevious();
        }

        @Override
        public boolean isFirst() {
            return cursor.isFirst();
        }

        @Override
        public boolean isLast() {
            return cursor.isLast();
        }

        @Override
        public boolean isBeforeFirst() {
            return cursor.isBeforeFirst();
        }

        @Override
        public boolean isAfterLast() {
            return cursor.isAfterLast();
        }

        @Override
        public int getColumnIndex(String columnName) {
            return cursor.getColumnIndex(columnName);
        }

        @Override
        public int getColumnIndexOrThrow(String columnName) throws IllegalArgumentException {
            return cursor.getColumnIndexOrThrow(columnName);
        }

        @Override
        public String getColumnName(int columnIndex) {
            return cursor.getColumnName(columnIndex);
        }

        @Override
        public String[] getColumnNames() {
            return cursor.getColumnNames();
        }

        @Override
        public int getColumnCount() {
            return cursor.getColumnCount();
        }

        @Override
        public byte[] getBlob(int columnIndex) {
            return cursor.getBlob(columnIndex);
        }

        @Override
        public String getString(int columnIndex) {
            return cursor.getString(columnIndex);
        }

        @Override
        public short getShort(int columnIndex) {
            return cursor.getShort(columnIndex);
        }

        @Override
        public int getInt(int columnIndex) {
            return cursor.getInt(columnIndex);
        }

        @Override
        public long getLong(int columnIndex) {
            return cursor.getLong(columnIndex);
        }

        @Override
        public float getFloat(int columnIndex) {
            return cursor.getFloat(columnIndex);
        }

        @Override
        public double getDouble(int columnIndex) {
            return cursor.getDouble(columnIndex);
        }

        @Override
        public int getType(int columnIndex) {
            return cursor.getType(columnIndex);
        }

        @Override
        public boolean isNull(int columnIndex) {
            return cursor.isNull(columnIndex);
        }

        @Override
        public void deactivate() {
            cursor.deactivate();
        }

        @Override
        public boolean requery() {
            return cursor.requery();
        }

        @Override
        public void close() {
            cursor.close();
        }

        @Override
        public boolean isClosed() {
            return cursor.isClosed();
        }

        @Override
        public FieldTypes getFieldTypes() {
            return cursor.getFieldTypes();
        }

        @Override
        public void copyStringToBuffer(int columnIndex, CharArrayBuffer buffer) {
            cursor.copyStringToBuffer(columnIndex, buffer);
        }

        @Override
        public void registerContentObserver(ContentObserver observer) {
            cursor.registerContentObserver(observer);
        }

        @Override
        public void unregisterContentObserver(ContentObserver observer) {
            cursor.registerContentObserver(observer);
        }

        @Override
        public void registerDataSetObserver(DataSetObserver observer) {
            cursor.registerDataSetObserver(observer);
        }

        @Override
        public void unregisterDataSetObserver(DataSetObserver observer) {
            cursor.unregisterDataSetObserver(observer);
        }

        @Override
        public void setNotificationUri(ContentResolver cr, Uri uri) {
            cursor.setNotificationUri(cr, uri);
        }

        @Override
        public Uri getNotificationUri() {
            return null;
        }

        @Override
        public boolean getWantsAllOnMoveCalls() {
            return cursor.getWantsAllOnMoveCalls();
        }

        @Override
        public void setExtras(Bundle extras) {

        }

        @Override
        public Bundle getExtras() {
            return cursor.getExtras();
        }

        @Override
        public Bundle respond(Bundle extras) {
            return cursor.respond(extras);
        }
    }
}

