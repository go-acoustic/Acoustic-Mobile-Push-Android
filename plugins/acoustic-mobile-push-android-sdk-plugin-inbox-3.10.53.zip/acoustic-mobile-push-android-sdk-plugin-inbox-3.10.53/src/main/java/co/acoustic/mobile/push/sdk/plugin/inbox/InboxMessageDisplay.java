/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

/**
 * This is the interface for the inbox template displky
 */
public interface InboxMessageDisplay {

   /**
     * This method displays the html message
     * @param message The message
     * @param activity The containing activity
     */
   void displayMessage(RichContent message, InboxMessageActivity activity);

    /**
     * This method is called when the message view is hidden
     * @param message The message
     * @param activityId The containing activity id
     */
    void viewHidden(RichContent message, long activityId);
}
