/*
 **********************************************************************************************
 * Copyright (C) 2026 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any
 * intellectual or industrial property rights of Acoustic, L.P. except as may
 * be provided in an agreement with Acoustic, L.P. Any unauthorized copying or
 * distribution of content from this file is prohibited.
 **********************************************************************************************
 */
package co.acoustic.mobile.push.sdk.plugin.inapp;

import android.content.Context;

/**
 * Renders an inApp message outside of the SDK, for hosts that display inApp content with their
 * own UI layer (for example Jetpack Compose) instead of an {@link InAppTemplate} fragment.
 *
 * <p>Register an implementation against a template name with
 * {@link InAppTemplateRegistry#registerExternalRenderer(String, InAppExternalRenderer)}. When
 * {@link InAppManager#show(Context, InAppStorage.KeyName, java.util.List,
 * androidx.fragment.app.FragmentManager, int)} selects a message whose template name is bound to
 * a renderer, the renderer is invoked instead of a fragment transaction. The SDK keeps ownership
 * of the message lifecycle: it sends the message opened event, increments the view count and
 * deletes the message once <code>maxViews</code> is reached, exactly as it does for a template
 * that renders through a fragment. Hosts must therefore not update the view count themselves.</p>
 */
public interface InAppExternalRenderer {

    /**
     * Displays, or hands off for display, the given inApp message.
     *
     * <p>Called on the thread that called {@link InAppManager#show(Context,
     * InAppStorage.KeyName, java.util.List, androidx.fragment.app.FragmentManager, int)}.
     * Implementations must not block.</p>
     *
     * @param context The context that was passed to the show call
     * @param payload The inApp message to display
     * @return true if the message was displayed and the view should be counted, false to leave
     *         the message and its view count untouched so that it can be displayed later
     */
    boolean render(Context context, InAppPayload payload);
}