/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inapp;

import java.util.HashMap;


/**
 * This is the registry for inApp message templates
 */
public class InAppTemplateRegistry {

   private static final InAppTemplateRegistry ourInstance = new InAppTemplateRegistry();

    private final HashMap<String, Class<? extends InAppTemplate>> registry = new HashMap<String, Class<? extends InAppTemplate>>();

    private final HashMap<String, InAppExternalRenderer> externalRenderers = new HashMap<String, InAppExternalRenderer>();

    /**
     * Retrieves the registry instance
     * @return The inatance
     */
    public static InAppTemplateRegistry getInstance() {
        return ourInstance;
    }

    private InAppTemplateRegistry() {
        registry.put("default", MiniTemplate.class);
        registry.put("image", ImageTemplate.class);
        registry.put("video", VideoTemplate.class);
    }

    /**
     * Registers an inApp template
     * @param templateName The template name
     * @param template The template
     */
    public void register(String templateName, Class<? extends InAppTemplate> template){
        registry.put(templateName, template);
    }

    /**
     * Removes an inApp template
     * @param templateName The template name
     */
    public void remove(String templateName){
        registry.remove(templateName);
    }

    /**
     * Gets a template by name
     * @param templateName The template name
     * @return The template
     */
    public Class<? extends InAppTemplate> get(String templateName){
        return registry.get(templateName);
    }

    /**
     * Registers a renderer that displays messages of the given template name outside of the SDK.
     * Use this for templates that are rendered by the host application, for example with Jetpack
     * Compose. The SDK keeps tracking the message views and maxViews lifecycle.
     * @param templateName The template name
     * @param renderer The renderer
     */
    public void registerExternalRenderer(String templateName, InAppExternalRenderer renderer){
        externalRenderers.put(templateName, renderer);
    }

    /**
     * Removes an external renderer
     * @param templateName The template name
     */
    public void removeExternalRenderer(String templateName){
        externalRenderers.remove(templateName);
    }

    /**
     * Gets the external renderer registered for a template name
     * @param templateName The template name
     * @return The renderer, or null if no renderer is registered for the template name
     */
    public InAppExternalRenderer getExternalRenderer(String templateName){
        return externalRenderers.get(templateName);
    }

}
