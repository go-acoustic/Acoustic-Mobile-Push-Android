/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inapp;

import android.content.Context;
import android.os.Bundle;
import androidx.annotation.IdRes;
import androidx.fragment.app.FragmentManager;

import co.acoustic.mobile.push.sdk.api.MceSdk;
import co.acoustic.mobile.push.sdk.util.Logger;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * This class manages inapp messages
 */
public class InAppManager {
    private static final String TAG = "InAppManager";


    /**
     * Show the first inapp message. The message can be the first of all the messages or it can be the first of messages with a given key value
     *
     * @param context         The application's context
     * @param key             The key for a key value search. For no search use null
     * @param values          The value for a key value search. For no search use null
     * @param fragmentManager The fragment manager that contains the fragment on which the view will be displayed
     * @param containerViewId The id of the view that the message will be displayed on
     */
    public static void show(final Context context, InAppStorage.KeyName key, List<String> values, final FragmentManager fragmentManager, final @IdRes int containerViewId) {
        try {
            if(!MceSdk.isSdkStopped(context)) {
                // The candidates are fetched once and scanned in memory. A message that cannot be
                // rendered is skipped without being deleted, so a template that is rendered by the
                // host application keeps its payload and its maxViews lifecycle (CA-146869).
                List<InAppPayload> candidates = InAppStorage.find(context, InAppStorage.Condition.ANY, key, values, false);
                for (InAppPayload inAppPayload : candidates) {
                    String templateName = inAppPayload.getTemplateName();
                    Class<? extends InAppTemplate> templateClass = InAppTemplateRegistry.getInstance().get(templateName);
                    if (templateClass != null) {
                        showWithTemplate(context, fragmentManager, containerViewId, inAppPayload, templateClass);
                        return;
                    }
                    InAppExternalRenderer externalRenderer = InAppTemplateRegistry.getInstance().getExternalRenderer(templateName);
                    if (externalRenderer != null) {
                        showWithExternalRenderer(context, inAppPayload, externalRenderer);
                        return;
                    }
                    Logger.d(TAG, "Skipping InApp message. Unknown template: " + templateName);
                }
            }
        } catch (Throwable t) {
            Logger.e(TAG, "Failed show inApp", t);
        }
    }

    private static void showWithTemplate(final Context context, final FragmentManager fragmentManager, final @IdRes int containerViewId, final InAppPayload inAppPayload, Class<? extends InAppTemplate> templateClass) {
        try {
            final InAppTemplate template = templateClass.getDeclaredConstructor().newInstance();
            if(!template.requiresOfflineResources()) {
                template.show(context, fragmentManager, containerViewId, inAppPayload, null); // pass InAppMessage
            } else {
                new Thread(() -> {
                    Map<String, Object> resources = template.createOfflineResources(context, inAppPayload);
                    template.show(context, fragmentManager, containerViewId, inAppPayload, resources); // pass InAppMessage
                }).start();
            }
            recordView(context, inAppPayload);
        } catch (Exception e) {
            Logger.e(TAG, "Error while showing the InApp Message. Details: " + e.getMessage(), e);
        }
    }

    private static void showWithExternalRenderer(Context context, InAppPayload inAppPayload, InAppExternalRenderer externalRenderer) {
        try {
            if (externalRenderer.render(context, inAppPayload)) {
                recordView(context, inAppPayload);
            } else {
                Logger.d(TAG, "External renderer did not display InApp message: " + inAppPayload.getId());
            }
        } catch (Exception e) {
            Logger.e(TAG, "Error while rendering the InApp Message externally. Details: " + e.getMessage(), e);
        }
    }

    /**
     * Counts a display of the message: reports the open, increments the view count and, for pull
     * sourced messages, sends the status update to the server.
     */
    private static void recordView(Context context, InAppPayload inAppPayload) {
        InAppEvents.sendInAppMessageOpenedEvent(context, inAppPayload);
        InAppStorage.updateMaxViews(context, inAppPayload);
        if(inAppPayload.isFromPull()) {
            InAppPlugin.updateInAppMessage(context, inAppPayload);
        }
    }

    /**
     * Show the first inapp message from all the inapp messages.
     *
     * @param context         The application's context
     * @param fragmentManager The fragment manager that contains the fragment on which the view will be displayed
     * @param containerViewId The id of the view that the message will be displayed on
     */
    public static void show(Context context, FragmentManager fragmentManager, @IdRes int containerViewId) {
        show(context, null, null, fragmentManager, containerViewId);
    }

    /**
     * Extracts an inapp segment of the notification if exists and adds it to the database
     *
     * @param context     The application's context
     * @param msgExtras   The bundle that contains the notification
     * @param attribution The attribution for the inapp message
     * @param mailingId The notification mailing id
     */
    public static void handleNotification(Context context, Bundle msgExtras, String attribution, String mailingId) {
        if (!msgExtras.containsKey("inApp")) {
            Logger.d(TAG, "inApp payload not found");
            return;
        }
        try {
            String inAppJSON = msgExtras.getString("inApp");
            Logger.d(TAG,"processing inApp payload: "+inAppJSON);
            if (inAppJSON != null) {
                InAppPayload inAppPayload = InAppPayloadJsonTemplate.inAppPayloadFromJSON(new JSONObject(inAppJSON));
                inAppPayload.setMceContext(attribution, mailingId);
                InAppStorage.save(context, inAppPayload, false);
                Logger.d(TAG,"Saved inApp payload: "+inAppPayload);
            } else {
                Logger.d(TAG, "inApp payload is null");
            }
        } catch (JSONException | IOException jsone) {
            Logger.e(TAG, "Error while parsing the InApp Message. Details: " + jsone.getMessage(), jsone);
        }

    }

    /**
     * Deletes an inapp message
     * @param context The application's context
     * @param messageId The inapp message id
     */
    public static void delete(Context context, String messageId) {
        InAppPayload inAppPayload = InAppStorage.getInappPayload(context, messageId);
        if(inAppPayload != null && inAppPayload.isFromPull()) {
            inAppPayload.finish();
            InAppPlugin.updateInAppMessage(context, inAppPayload);
        }
        InAppStorage.delete(context, messageId);

    }



    /**
     * This method clears all inapp messages
     * @param context The application's context
     */
    public static void clearData(Context context) {
        Logger.d(TAG, "Clearing inApp data");
        InAppStorage.clear(context);
    }




}
