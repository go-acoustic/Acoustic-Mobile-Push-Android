/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inapp;


import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.os.Bundle;

import java.util.Iterator;
import java.util.Map;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import co.acoustic.mobile.push.sdk.util.Logger;

import android.app.Activity;
import android.content.ContextWrapper;
import android.os.Handler;
import android.os.Looper;
import androidx.lifecycle.Lifecycle;

/**
 * This class is the base inapp template class
 */
public abstract class BaseInAppTemplate implements InAppTemplate {

    static final String MESSAGE_ID_KEY = "messageId";
    static final String IN_APP_MESSAGE_ID_KEY = "inAppMessageId";
    static final String IN_APP_CONTENT_ID_KEY = "inAppContentId";
    static final String ATTRIBUTION_KEY = "attribution";
    static final String MAILING_ID_KEY = "mailingId";
    static final String ACTION_KEY = "action";
    static final String ACTION_TYPE_KEY = "actionType";
    static final String TYPE_KEY = "type";
    static final String PAYLOAD_KEY = "payload";
    private static final String TAG ="BaseInAppTemplate";

    /**
     * This method shows the inapp message
     * @param context The application's context
     * @param fragmentManager The fragment manager
     * @param containerViewId The container view id
     * @param message The inapp message
     * @param offlineResources Offline resources required for display
     */
    @Override
    public void show(Context context, FragmentManager fragmentManager, int containerViewId, InAppPayload message, Map<String, Object> offlineResources) {
        // Ensure we're on the main thread
        if (Looper.myLooper() != Looper.getMainLooper()) {
            Handler mainHandler = new Handler(Looper.getMainLooper());
            mainHandler.post(() -> show(context, fragmentManager, containerViewId, message, offlineResources));
            return;
        }

        try {
            // Check if FragmentManager is in a valid state
            if (fragmentManager.isStateSaved()) {
                Logger.d(TAG, "Cannot show in-app message: FragmentManager state is saved");
                return;
            }

            // If context is a FragmentActivity, check with lifecycle-aware approach
            if (context instanceof androidx.fragment.app.FragmentActivity fragmentActivity) {
                if (fragmentActivity.isFinishing() || fragmentActivity.isDestroyed()) {
                    Logger.d(TAG, "Cannot show in-app message: FragmentActivity is finishing or destroyed");
                    return;
                }

                // Additional check for lifecycle state
                if (fragmentActivity.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED)) {
                    performFragmentTransaction(context, fragmentManager, containerViewId, message, offlineResources);
                } else {
                    Logger.d(TAG, "Cannot show in-app message: Activity lifecycle not in appropriate state");
                }
            } else {
                // Walk any ContextWrapper chain (e.g. ContextThemeWrapper) to find a backing
                // Activity before deciding the message is host-less.
                Activity activity = findActivity(context);
                if (activity != null) {
                    if (activity.isFinishing() || activity.isDestroyed()) {
                        Logger.d(TAG, "Cannot show in-app message: Activity is finishing or destroyed");
                    } else {
                        performFragmentTransaction(context, fragmentManager, containerViewId, message, offlineResources);
                    }
                } else {
                    // Application/Service Context paired with an Activity-owned FragmentManager:
                    // proceed (the FragmentManager's host drives lifecycle/theme/window) but warn.
                    // The Context is forwarded to setupArguments(); a subclass that misuses it
                    // will fall into the outer catch below.
                    String contextType = (context == null) ? "null" : context.getClass().getName();
                    String fragmentManagerType = fragmentManager.getClass().getName();
                    Logger.w(TAG, "In-app show() called with non-Activity Context [" + contextType
                            + "] paired with Activity-owned FragmentManager [" + fragmentManagerType
                            + "]. Proceeding because the FragmentManager's host drives Fragment"
                            + " lifecycle, but subclasses of BaseInAppTemplate must not assume the"
                            + " Context is an Activity. To silence this warning, pass an Activity"
                            + " Context (e.g. 'this' from your Activity, or 'requireActivity()'"
                            + " from a Fragment) to InAppManager.show() instead of"
                            + " getApplicationContext().");
                    performFragmentTransaction(context, fragmentManager, containerViewId, message, offlineResources);
                }
            }

        } catch (IllegalStateException e) {
            Logger.e(TAG, "Fragment transaction failed due to state loss", e);
        } catch (Exception e) {
            Logger.e(TAG, "Error while showing in-app message", e);
        }
    }

    private void performFragmentTransaction(Context context, FragmentManager fragmentManager, int containerViewId, InAppPayload message, Map<String, Object> offlineResources) {
        try {
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            InAppFragment fragment = createFragment();
            Bundle arguments = new Bundle();

            arguments.putString(MESSAGE_ID_KEY, message.getId());
            arguments.putString(ATTRIBUTION_KEY, message.getAttribution());
            arguments.putString(MAILING_ID_KEY, message.getMailingId());

            JSONObject actionJSON = message.getTemplateContent().optJSONObject(ACTION_KEY);
            if(actionJSON != null) {
                arguments.putString(ACTION_TYPE_KEY, actionJSON.getString(TYPE_KEY));
                Bundle payload = new Bundle();
                payload.putString(IN_APP_MESSAGE_ID_KEY, message.getId());
                payload.putString(IN_APP_CONTENT_ID_KEY, message.getContentId());
                Iterator<String> keys = actionJSON.keys();
                while(keys.hasNext()) {
                    String key = keys.next();
                    if(!key.equals(TYPE_KEY)) {
                        payload.putString(key, actionJSON.get(key).toString());
                    }
                }
                arguments.putBundle(PAYLOAD_KEY, payload);
            }

            setupArguments(context, message, arguments, offlineResources);
            fragment.setArguments(arguments);
            fragmentTransaction.add(containerViewId, fragment, getFragmentLayoutId());

            // commitAllowingStateLoss(): if state has been saved between the isStateSaved() check
            // and now, drop the commit instead of throwing. The user can re-show on next launch.
            fragmentTransaction.commitAllowingStateLoss();

        } catch (JSONException e) {
            Logger.e(TAG, "Error while showing notification.", e);
        }
    }

    /**
     * Walks the ContextWrapper chain looking for an Activity. Returns null for
     * Application or Service Contexts, which have no Activity in their wrapper chain.
     */
    private static Activity findActivity(Context context) {
        Context current = context;
        while (current instanceof ContextWrapper) {
            if (current instanceof Activity) {
                return (Activity) current;
            }
            current = ((ContextWrapper) current).getBaseContext();
        }
        return null;
    }

    protected abstract void setupArguments(Context context, InAppPayload message, Bundle arguments, Map<String, Object> offlineResources) throws JSONException;

    protected abstract String getFragmentLayoutId();

    protected abstract InAppFragment createFragment();
}
