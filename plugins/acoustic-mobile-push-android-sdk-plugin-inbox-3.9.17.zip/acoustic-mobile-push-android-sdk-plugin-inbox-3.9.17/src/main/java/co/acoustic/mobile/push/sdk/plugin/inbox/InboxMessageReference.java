/*
 * Copyright © 2011, 2019 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;


import android.content.Context;
import android.content.Intent;

import org.json.JSONException;
import org.json.JSONObject;

public class InboxMessageReference extends JSONObject {

    public static final String INBOX_MESSAGE_ID_KEY = "inboxMessageId";
    public static final String CONTENT_ID_KEY = "contentId";

    private String inboxMessageId;
    private String contentId;

    public InboxMessageReference(Intent intent) {
        this(intent.getStringExtra(CONTENT_ID_KEY), intent.getStringExtra(INBOX_MESSAGE_ID_KEY));
    }

    public InboxMessageReference(String contentId, String inboxMessageId) {
        try {
            if (inboxMessageId != null) {
                put(INBOX_MESSAGE_ID_KEY, inboxMessageId);
                this.inboxMessageId = inboxMessageId;
            } else {
                put(CONTENT_ID_KEY, contentId);
                this.contentId = contentId;
            }
        } catch (JSONException jsone) {

        }
    }

    public String getInboxMessageId() {
        return inboxMessageId;
    }

    public String getContentId() {
        return contentId;
    }

    public void addToIntent(Intent intent) {
        if(contentId != null) {
            intent.putExtra(CONTENT_ID_KEY, contentId);
        }
        if(inboxMessageId != null) {
            intent.putExtra(INBOX_MESSAGE_ID_KEY, inboxMessageId);
        }
    }

    public void removeFromIntent(Intent intent) {
        intent.removeExtra(CONTENT_ID_KEY);
        intent.removeExtra(INBOX_MESSAGE_ID_KEY);
    }

    public InboxMessageReference(RichContent richContent) {
        this(richContent.getContentId(), richContent.getMessageId());
    }

    public InboxMessageReference(String json) throws JSONException {
        super(json);
        this.inboxMessageId = optString(INBOX_MESSAGE_ID_KEY);
        if(inboxMessageId == null) {
            this.contentId = optString(CONTENT_ID_KEY);
        }
    }

    public boolean isReferencedMessage(RichContent richContent) {
        if(richContent == null) {
            return false;
        }
        if(inboxMessageId != null) {
            return richContent.getMessageId().equals(inboxMessageId);
        } else if (contentId != null){
            return richContent.getContentId().equals(contentId);
        } else {
            return false;
        }
    }

    public RichContent getMessageFromDb(Context context) {
        if(inboxMessageId != null) {
            return InboxMessagesClient.getInboxMessageByMessageId(context, inboxMessageId);
        } else if(contentId != null){
            return InboxMessagesClient.getInboxMessageByContentId(context, contentId);
        } else {
            return null;
        }
    }

    public boolean hasReference() {
        return contentId != null || inboxMessageId != null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InboxMessageReference)) return false;

        InboxMessageReference that = (InboxMessageReference) o;

        if (inboxMessageId != null ? !inboxMessageId.equals(that.inboxMessageId) : that.inboxMessageId != null)
            return false;
        return contentId != null ? contentId.equals(that.contentId) : that.contentId == null;

    }

    @Override
    public int hashCode() {
        int result = inboxMessageId != null ? inboxMessageId.hashCode() : 0;
        result = 31 * result + (contentId != null ? contentId.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "InboxMessageReference{" +
                "inboxMessageId='" + inboxMessageId + '\'' +
                ", contentId='" + contentId + '\'' +
                '}';
    }
}
