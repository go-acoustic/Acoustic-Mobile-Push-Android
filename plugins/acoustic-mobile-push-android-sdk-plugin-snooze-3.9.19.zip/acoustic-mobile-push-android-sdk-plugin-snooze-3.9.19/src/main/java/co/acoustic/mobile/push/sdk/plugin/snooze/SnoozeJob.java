/*
 *  Copyright © 2011, 2020 Acoustic, L.P. All rights reserved.
 *
 *  NOTICE: This file contains material that is confidential and proprietary to
 *  Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 *  industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 *  Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.
 *
 */

package co.acoustic.mobile.push.sdk.plugin.snooze;

import android.app.job.JobParameters;
import android.content.Context;
import android.os.Bundle;

import org.json.JSONException;

import co.acoustic.mobile.push.sdk.api.Constants;
import co.acoustic.mobile.push.sdk.job.MceJobService;
import co.acoustic.mobile.push.sdk.job.MceSdkOneTimeJob;
import co.acoustic.mobile.push.sdk.notification.AlertProcessor;
import co.acoustic.mobile.push.sdk.notification.NotificationsUtility;
import co.acoustic.mobile.push.sdk.util.Logger;

public class SnoozeJob implements MceSdkOneTimeJob<Bundle> {

    private static final String TAG = "SnoozeJob";

    @Override
    public long[] getBackoffPlan(Context context) {
        return new long[]{1, 1, 2, 5, 10, 20, 30, 60, 90};
    }

    @Override
    public boolean startJob(Context context, MceJobService mceJobService, Bundle parameters, JobParameters jobParameters, String jobId) {
        Logger.d(TAG, "Snooze done");
        Bundle extras = new Bundle();
        extras.putString(Constants.Notifications.ALERT_KEY, parameters.getString(Constants.Notifications.SOURCE_NOTIFICATION_KEY));
        extras.putString(Constants.Notifications.MCE_PAYLOAD_KEY, parameters.getString(Constants.Notifications.SOURCE_MCE_PAYLOAD_KEY));
        try {
            AlertProcessor.processAlert(context, extras);
        } catch (JSONException jsone) {
            Logger.e(TAG, "Failed to parse notification", jsone);
        }
        return true;
    }

    @Override
    public void endJob(MceJobService mceJobService, Bundle parameters) {

    }

    @Override
    public boolean isThreaded() {
        return false;
    }
}
