/*
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 */
package co.acoustic.mobile.push.sdk.plugin.inbox;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import co.acoustic.mobile.push.sdk.Preferences;
import co.acoustic.mobile.push.sdk.util.Logger;

class InboxPreferences extends Preferences {

    public static final String TAG = "InboxPreferences";

    private static final String INBOX_STATUS_UPDATE_PAYLOAD = "inboxStatusUpdatePayload";
    private static final String INBOX_SETTING_PAYLOAD_MSG = "Setting inbox status payload to ";


    public static String getInboxStatusUpdatePayload(Context context) {
        return getString(context, INBOX_STATUS_UPDATE_PAYLOAD, null);
    }

    public static void setInboxStatusUpdatePayload(Context context, String payload) {
        setString(context, INBOX_STATUS_UPDATE_PAYLOAD, payload);
        Logger.d(TAG,INBOX_SETTING_PAYLOAD_MSG + payload);
    }

    public static void cleanInboxStatusPayload(Context context, String payload) {

        // If payload is null, clear stored value immediately
        if (payload == null) {
            setString(context, INBOX_STATUS_UPDATE_PAYLOAD, null);
            Logger.d(TAG, INBOX_SETTING_PAYLOAD_MSG + "null");
            return;
        }

        try {
            JSONObject payloadJSON = new JSONObject(payload);
            JSONArray updates = payloadJSON.optJSONArray("updates");

            // If there is an updates array, filter out entries with null/empty inboxMessageId
            if (updates != null) {
                JSONArray filtered = new JSONArray();
                for (int i = 0; i < updates.length(); i++) {
                    JSONObject upd = updates.optJSONObject(i);
                    if (upd == null) {
                        continue;
                    }
                    String inboxId = upd.optString("inboxMessageId", "");
                    if (inboxId.trim().isEmpty()) {
                        Logger.d(TAG, "Removing update with empty inboxMessageId: " + upd);
                        continue;
                    }
                    filtered.put(upd);
                }

                if (filtered.length() == 0) {
                    // No valid updates remain -> clear stored payload
                    setString(context, INBOX_STATUS_UPDATE_PAYLOAD, null);
                    Logger.d(TAG, "All updates removed due to empty inboxMessageId. Cleared stored payload.");
                    return;
                } else if (filtered.length() != updates.length()) {
                    // Some were removed -> store cleaned payload
                    JSONObject newPayload = new JSONObject();
                    newPayload.put("updates", filtered);
                    String cleaned = newPayload.toString();
                    setString(context, INBOX_STATUS_UPDATE_PAYLOAD, cleaned);
                    Logger.d(TAG, INBOX_SETTING_PAYLOAD_MSG + cleaned);
                    return;
                }
            }

            // No changes needed, store original payload
            setString(context, INBOX_STATUS_UPDATE_PAYLOAD, payload);
            Logger.d(TAG, INBOX_SETTING_PAYLOAD_MSG + payload);
        } catch (JSONException e) {
            // On parse error, preserve original payload but log the issue
            setString(context, INBOX_STATUS_UPDATE_PAYLOAD, payload);
            Logger.e(TAG, "Failed to parse/clean update payload, storing original payload: " + payload, e);
        }
    }
}
