/********************************************************************************************
 * Copyright (C) 2024 Acoustic, L.P. All rights reserved.
 *
 * NOTICE: This file contains material that is confidential and proprietary to
 * Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
 * industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
 * Acoustic, L.P. Any unauthorized copying or distribution of content from this file is
 * prohibited.
 ********************************************************************************************/
package co.acoustic.mobile.push.sdk.plugin.inbox;

import co.acoustic.mobile.push.sdk.util.Logger;

public class InboxPlugin {
    public static final String VERSION_NUMBER = "3.10.45";
    private static final String TAG = "InboxPlugin";

    private static InboxControl inboxControl = new DefaultInboxControl();

    /**
     * This method delegate the request to the control's shouldDisplayInboxMessage method
     * @param richContent The message
     * @return true fdor display, false otherwise.
     */
    public static boolean shouldDisplayInboxMessage(RichContent richContent) {
        try {
            return inboxControl.shouldDisplayInboxMessage(richContent);
        } catch (Throwable t) {
            Logger.e(TAG, "Inbox display control failed on "+richContent,t);
            return true;
        }

    }

    /**
     * Sets the inbox control implementation
     * @param control The inbox control
     */
    public static void setInboxControl(InboxControl control) {
        if(control != null) {
            inboxControl = control;
        } else {
            inboxControl = new DefaultInboxControl();
        }
    }

    /**
     * Retrieves the inbox control implementation
     * @return The inbox control
     */
    public static InboxControl getInboxControl() {
        return inboxControl;
    }

    /**
     * This interface is for inbox control implementation
     */
    public interface InboxControl {
        /**
         * Checks if the message should be displayed in the inbox
         * @param richContent The message
         * @return true for display, false for no display
         */
        boolean shouldDisplayInboxMessage(RichContent richContent);

        /**
         * Checks is inbox messages will be displayed in ascending order (ascending means oldest first).
         * @return true for ascending, false for descending (newest first)
         */
        boolean isMessagesSortAscending();

        /**
         * This method is called every time an inbox message is received in a simple push message
         * @param messageId The message id
         * @param contentId The message content id
         * @return true if this message should be loaded immediately from the server, false otherwise
         */
        boolean shouldFetchMessageFromAlert(String messageId, String contentId);

        /**
         * This method is called just before a message is inserted to the sdk message db
         * @param message The new message
         * @return The message that will be added to the database or null for not adding anything
         */
        RichContent processMessageBeforeDbStorage(RichContent message);

        /**
         * This method is called right after a message is added to the sdk message db
         * @param message The added message
         */
        void messageAddedToDbStorage(RichContent message);

        /**
         * This method retrieves the activity class used for rich inbox display;
         * @return
         */
        Class getRichInboxActivityClass();
    }

    static class DefaultInboxControl implements InboxControl {

        private static Class richOInboxActivityClass = null;
        static {
            try {
                richOInboxActivityClass =  Class.forName("co.acoustic.mobile.push.sdk.plugin.inbox.RichInboxActivity");
            } catch (Throwable t ) {
                Logger.w(TAG, "Failed to load inbox activity class");
            }
        }

        @Override
        public boolean shouldDisplayInboxMessage(RichContent richContent) {
            return !richContent.getIsExpired();
        }

        @Override
        public boolean isMessagesSortAscending() {
            return true;
        }

        @Override
        public boolean shouldFetchMessageFromAlert(String messageId, String contentId) {
            return true;
        }

        @Override
        public RichContent processMessageBeforeDbStorage(RichContent message) {
            return message;
        }

        @Override
        public void messageAddedToDbStorage(RichContent message) {

        }

        @Override
        public Class getRichInboxActivityClass() {
            return richOInboxActivityClass;
        }
    }
}
